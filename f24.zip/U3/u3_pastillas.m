function R = u3_pastillas(p)
%U3_PASTILLAS Reglaje de la holgura de válvulas con pastillas calibradas.
%   R = u3_pastillas(p)
%
%   Parámetros (estructura p):
%     tipo        'A' admisión / 'E' escape por válvula (char de 8)       ['AEAEAEAE']
%     holgura     holgura medida con galgas (mm), 8 valores
%     pastilla    espesor de la pastilla actual (mm), 8 valores
%     nominal_A, rango_A   holgura nominal y rango de admisión (mm)      [0.20, [0.15 0.25]]
%     nominal_E, rango_E   holgura nominal y rango de escape (mm)        [0.25, [0.20 0.30]]
%     paso        escalón de espesores disponibles (mm)                  [0.05]
%
%   Pastilla nueva = pastilla actual + (holgura medida − holgura nominal),
%   redondeada al espesor disponible.
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('tipo', 'AEAEAEAE', 'holgura', [0.18 0.32 0.21 0.27 0.12 0.24 0.20 0.35], ...
    'pastilla', [2.65 2.80 2.70 2.75 2.60 2.85 2.70 2.90], 'nominal_A', 0.20, 'rango_A', [0.15 0.25], ...
    'nominal_E', 0.25, 'rango_E', [0.20 0.30], 'paso', 0.05));
c = sfm_colores();
nv = numel(p.holgura); nueva = p.pastilla; ok = true(1, nv); nom = zeros(1, nv); lo = nom; hi = nom;
fprintf('\nReglaje de válvulas con pastillas\n');
fprintf('  %-7s %-5s %-10s %-11s %-10s %-11s %-10s\n', 'Válvula', 'Tipo', 'Holgura', 'Pastilla', '¿En rango?', 'Calculada', 'A montar');
for k = 1:nv
    if p.tipo(k) == 'A', nom(k) = p.nominal_A; r = p.rango_A; else, nom(k) = p.nominal_E; r = p.rango_E; end
    lo(k) = r(1); hi(k) = r(2);
    ok(k) = p.holgura(k) >= r(1) && p.holgura(k) <= r(2);
    calc = p.pastilla(k) + p.holgura(k) - nom(k);
    if ~ok(k), nueva(k) = round(calc/p.paso)*p.paso; end
    if ok(k), txt = 'Sí'; else, txt = 'No: cambiar'; end
    fprintf('  %-7d %-5s %-10.2f %-11.2f %-10s %-11.2f %-10.2f\n', k, p.tipo(k), p.holgura(k), p.pastilla(k), txt, calc, nueva(k));
end
fprintf('  %d de %d válvulas necesitan cambio de pastilla.\n', sum(~ok), nv);
R = struct('en_rango', ok, 'pastilla_nueva', nueva, 'holgura_final', p.holgura + p.pastilla - nueva);
sfm_fig('Pastillas de reglaje', 900, 450); hold on
for k = 1:nv, fill(k + [-0.4 0.4 0.4 -0.4], [lo(k) lo(k) hi(k) hi(k)], [0.85 0.95 0.85], 'EdgeColor', 'none'); end
b1 = bar((1:nv) - 0.18, p.holgura, 0.35); set(b1, 'FaceColor', c.naranja);
b2 = bar((1:nv) + 0.18, R.holgura_final, 0.35); set(b2, 'FaceColor', c.azul);
set(gca, 'XTick', 1:nv); grid on; xlabel('Válvula'); ylabel('Holgura (mm)')
legend([b1 b2], 'Medida', 'Con la pastilla nueva', 'Location', 'northoutside', 'Orientation', 'horizontal')
title('Holgura medida y corregida (franja verde = rango admisible)')
end
