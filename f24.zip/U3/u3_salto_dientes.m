function R = u3_salto_dientes(p)
%U3_SALTO_DIENTES Efecto de un salto de dientes de la correa o cadena de distribución.
%   R = u3_salto_dientes(p)
%
%   Parámetros (estructura p):
%     Z        dientes del piñón del árbol de levas                [42]
%     dientes  dientes desfasados (+ árbol retrasado, − adelantado) [1]
%     S, L     carrera y longitud de biela (mm)                    [70 130]
%     Rc       relación de compresión geométrica                   [9.5]
%     AAA, RCA, AAE, RCE   cotas en fase (°)                        [12 48 50 10]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('Z', 42, 'dientes', 1, 'S', 70, 'L', 130, 'Rc', 9.5, 'AAA', 12, 'RCA', 48, 'AAE', 50, 'RCE', 10));
c = sfm_colores();
d1 = 720/p.Z; dl = p.dientes*d1;
rce = @(rca) local_rc_ef(p, rca);
n = struct('AAA', p.AAA - dl, 'RCA', p.RCA + dl, 'AAE', p.AAE - dl, 'RCE', p.RCE + dl);
R = struct('desfase_diente', d1, 'desfase', dl, 'cotas', n, 'Rc_ef_fase', rce(p.RCA), 'Rc_ef_desfasada', rce(n.RCA));
sfm_tabla('Salto de dientes', { ...
    'Desfase por diente (° cigüeñal)', d1, '%.2f', '720/Z'; 'Desfase total (°)', dl, '%.2f', ''; ...
    'AAA | RCA en fase (°)', sprintf('%g | %g', p.AAA, p.RCA), '', ''; 'AAA | RCA desfasadas (°)', sprintf('%.1f | %.1f', n.AAA, n.RCA), '', ''; ...
    'AAE | RCE desfasadas (°)', sprintf('%.1f | %.1f', n.AAE, n.RCE), '', ''; ...
    'Cruce en fase | desfasado (°)', sprintf('%g | %.1f', p.AAA + p.RCE, n.AAA + n.RCE), '', ''; ...
    'Compresión efectiva en fase', R.Rc_ef_fase, '%.2f', 'volumen al cerrar la admisión / Vc'; ...
    'Compresión efectiva desfasada', R.Rc_ef_desfasada, '%.2f', ''});
if R.Rc_ef_desfasada < R.Rc_ef_fase - 0.3, fprintf('  El retraso reduce la compresión efectiva: arranque difícil y menos par a bajo régimen.\n'); end
fprintf('  En motores de interferencia gire siempre dos vueltas a mano antes de arrancar.\n');
th = 0:0.5:720;
sfm_fig('Salto de dientes', 1100, 450);
subplot(1,2,1); hold on
plot(th, u3_alzada_valvula(th, 180 - p.AAE, p.AAE + 180 + p.RCE, 8), 'Color', c.rojo, 'LineWidth', 2);
plot(th, u3_alzada_valvula(th, 360 - p.AAA, p.AAA + 180 + p.RCA, 9), 'Color', c.azul, 'LineWidth', 2);
plot(th, u3_alzada_valvula(th, 180 - p.AAE + dl, p.AAE + 180 + p.RCE, 8), '--', 'Color', c.rojo, 'LineWidth', 1.5);
plot(th, u3_alzada_valvula(th, 360 - p.AAA + dl, p.AAA + 180 + p.RCA, 9), '--', 'Color', c.azul, 'LineWidth', 1.5);
xlim([0 720]); set(gca, 'XTick', 0:90:720); grid on; xlabel('Cigüeñal (°)'); ylabel('Alzada (mm)')
legend('Escape en fase', 'Admisión en fase', 'Escape desfasado', 'Admisión desfasada', 'Location', 'northwest'); title(sprintf('%+d diente(s) = %+.1f°', p.dientes, dl))
subplot(1,2,2); r = 20:2:90; v = arrayfun(rce, r); plot(r, v, 'Color', c.verde, 'LineWidth', 1.8); hold on
plot(p.RCA, R.Rc_ef_fase, 'ko', 'MarkerFaceColor', c.azul); plot(n.RCA, R.Rc_ef_desfasada, 'ks', 'MarkerFaceColor', c.naranja)
grid on; xlabel('RCA (°)'); ylabel('Compresión efectiva'); title('Compresión efectiva según el cierre de la admisión'); legend('curva', 'en fase', 'desfasada')
end

function rc = local_rc_ef(p, rca)
r = p.S/2; lam = r/p.L; a = (180 - rca)*pi/180;
x = r*(1 - cos(a)) + p.L*(1 - sqrt(1 - lam^2*sin(a)^2));     % mm desde el PMS
Vu = 1; Vc = Vu/(p.Rc - 1);                                     % volúmenes relativos
rc = (Vc + Vu*x/p.S)/Vc;
end
