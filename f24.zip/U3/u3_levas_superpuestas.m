function R = u3_levas_superpuestas(p)
%U3_LEVAS_SUPERPUESTAS Perfil de las levas de admisión y escape y separación entre levas (LSA).
%   R = u3_levas_superpuestas(p)
%
%   Parámetros (estructura p):
%     AAE, RCE, AAA, RCA   cotas (°)                       [50 10 12 48]
%     HE, HA               alzada máxima (mm)             [8 9]
%     rb                   radio del círculo base (mm)    [18]
%     rampa                fracción de rampa              [0.42]
%     girar                true: anima el giro del árbol   [false]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('AAE', 50, 'RCE', 10, 'AAA', 12, 'RCA', 48, 'HE', 8, 'HA', 9, 'rb', 18, 'rampa', 0.42, 'girar', false));
c = sfm_colores();
dE = p.AAE + 180 + p.RCE; dA = p.AAA + 180 + p.RCA;
ECL = dE/2 - p.RCE; ICL = dA/2 - p.AAA; LSA = (ECL + ICL)/2;
R = struct('ECL', ECL, 'ICL', ICL, 'LSA', LSA, 'cruce', p.AAA + p.RCE);
sfm_tabla('Levas superpuestas', { ...
    'Centro de la leva de escape ECL (° antes del PMS)', ECL, '%.1f', 'durE/2 − RCE'; ...
    'Centro de la leva de admisión ICL (° después del PMS)', ICL, '%.1f', 'durA/2 − AAA'; ...
    'Separación entre levas LSA (° de árbol)', LSA, '%.1f', '(ECL + ICL)/2'; ...
    'Cruce (° cigüeñal)', p.AAA + p.RCE, '%.0f', 'AAA + RCE'});
phi = 0:0.5:359.5;                        % ángulo del árbol, desde el PMS de cruce
thc = mod(360 + 2*phi, 720);
rE = p.rb + u3_alzada_valvula(thc, 180 - p.AAE, dE, p.HE, p.rampa);
rA = p.rb + u3_alzada_valvula(thc, 360 - p.AAA, dA, p.HA, p.rampa);
sfm_fig('Levas superpuestas', 700, 650); hold on; axis equal; axis off
a = phi*pi/180;
hE = fill(rE.*sin(-a), rE.*cos(-a), c.rojo, 'FaceAlpha', 0.35, 'EdgeColor', c.rojo, 'LineWidth', 1.5);
hA = fill(rA.*sin(-a), rA.*cos(-a), c.azul, 'FaceAlpha', 0.35, 'EdgeColor', c.azul, 'LineWidth', 1.5);
plot([0 0], [0 p.rb + max(p.HE, p.HA) + 4], 'k--'); text(1, p.rb + max(p.HE, p.HA) + 2, 'PMS de cruce', 'FontSize', 8)
legend([hE hA], 'Leva de escape', 'Leva de admisión', 'Location', 'southoutside')
title(sprintf('Levas en el árbol · LSA = %.1f° de árbol', LSA))
if p.girar
    for g = 0:5:360
        set(hE, 'XData', rE.*sin(-a + g*pi/180), 'YData', rE.*cos(-a + g*pi/180));
        set(hA, 'XData', rA.*sin(-a + g*pi/180), 'YData', rA.*cos(-a + g*pi/180)); drawnow; pause(0.03);
    end
end
end
