function R = u3_apriete_culata(p)
%U3_APRIETE_CULATA Secuencia de apriete/aflojado de la culata y control de la práctica.
%   R = u3_apriete_culata(p)
%
%   Parámetros (estructura p):
%     n_tornillos   número de tornillos (par: 8 … 18)                  [10]
%     etapas        [par1 par2 ang3 ang4] (N·m, N·m, °, °; ang4 = 0 si no aplica)  [30 60 90 90]
%     L_nominal     longitud nominal del tornillo (mm)                 [120]
%     alarg_max     alargamiento máximo admisible (mm)                 [0.5]
%     tol_par       tolerancia del par (± %)                           [5]
%     registro      matriz n×5 con [par1 par2 ang3 ang4 longitud] medidos por paso ([] = sin registro)
%
%   Secuencia genérica en espiral desde el centro y en cruz; prevalece el manual.
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('n_tornillos', 10, 'etapas', [30 60 90 90], 'L_nominal', 120, 'alarg_max', 0.5, ...
    'tol_par', 5, 'registro', [30 60 90 90 120.2; 31 59 90 90 120.6]));
c = sfm_colores();
n = p.n_tornillos; m = n/2;
if mod(n, 2) || n < 8 || n > 18, error('Use un número par de tornillos entre 8 y 18.'); end
cen = (m + 1)/2; [~, ordc] = sort(abs((1:m) - cen) + 1e-3*(1:m));
O = zeros(2, m); k = 1; i = 1;                    % fila 1 = superior, fila 2 = inferior
while i <= m
    col = ordc(i);
    if abs(col - cen) < 1e-9, O(1, col) = k; O(2, col) = k + 1; k = k + 2; i = i + 1;
    else
        l = ordc(i); r = ordc(i + 1); if l > r, [l, r] = deal(r, l); end
        O(1, l) = k; O(2, r) = k + 1; O(1, r) = k + 2; O(2, l) = k + 3; k = k + 4; i = i + 2;
    end
end
R = struct('orden_apriete', O, 'orden_aflojado', n + 1 - O);
fprintf('\nOrden de APRIETE (fila superior = lado de admisión):\n'); disp(O)
fprintf('Orden de AFLOJADO (inverso):\n'); disp(n + 1 - O)
estado = {};
if ~isempty(p.registro)
    fprintf('Control del apriete:\n');
    for s = 1:size(p.registro, 1)
        g = p.registro(s, :); e = p.etapas;
        okp = abs(g(1) - e(1)) <= e(1)*p.tol_par/100 && abs(g(2) - e(2)) <= e(2)*p.tol_par/100 && ...
              abs(g(3) - e(3)) <= 3 && (e(4) == 0 || abs(g(4) - e(4)) <= 3);
        if okp, st = 'Correcto'; else, st = 'Revisar'; end
        if g(5) > p.L_nominal + p.alarg_max, tor = 'Sustituir (alargado)'; else, tor = 'Reutilizable'; end
        fprintf('  Paso %2d: %-9s tornillo %s\n', s, st, tor); estado(s, :) = {st, tor}; %#ok<AGROW>
    end
end
R.estado = estado;
sfm_fig('Apriete de culata', 900, 420); hold on; axis equal; axis off
rectangle('Position', [0.3 0.2 m + 0.4 2.6], 'Curvature', 0.08, 'FaceColor', [0.87 0.9 0.94], 'EdgeColor', [0.4 0.4 0.4]);
for col = 1:m
    for f = 1:2
        y = 2.2 - (f - 1)*1.4;
        rectangle('Position', [col + 0.5 - 0.28, y - 0.28, 0.56, 0.56], 'Curvature', 1, 'FaceColor', 'w', 'EdgeColor', 'k');
        text(col + 0.5, y, sprintf('%d', O(f, col)), 'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'Color', c.rojo, 'FontSize', 13);
        text(col + 0.5, y - 0.45*(3 - 2*f) , sprintf('(%d)', n + 1 - O(f, col)), 'HorizontalAlignment', 'center', 'Color', c.azul, 'FontSize', 8);
    end
end
text(m/2 + 0.5, 3.15, 'Lado de admisión', 'HorizontalAlignment', 'center'); text(m/2 + 0.5, -0.15, 'Lado de escape', 'HorizontalAlignment', 'center');
title(sprintf('Apriete (rojo) y aflojado (azul) · %d tornillos · etapas %g N·m, %g N·m, %g°, %g°', n, p.etapas));
axis([0 m + 1 -0.4 3.4]);
end
