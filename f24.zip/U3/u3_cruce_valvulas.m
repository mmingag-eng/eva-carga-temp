function R = u3_cruce_valvulas(p)
%U3_CRUCE_VALVULAS Alzado de las válvulas, cruce (base, máximo, mínimo) y diagrama circular.
%   R = u3_cruce_valvulas(p)
%
%   Parámetros (estructura p):
%     AAE, RCE, AAA, RCA   cotas de distribución (°)                  [50 10 12 48]
%     HE, HA               alzada máxima de escape y admisión (mm)    [8 9]
%     rampa                fracción de rampa del perfil (0,10–0,50)   [0.42]
%     VE, VA               variación de fase del escape/admisión (±°) [15 15]
%
%   Referencias: PMS de combustión 0°/720°, PMI 180°/540°, PMS de cruce 360°.
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('AAE', 50, 'RCE', 10, 'AAA', 12, 'RCA', 48, 'HE', 8, 'HA', 9, 'rampa', 0.42, 'VE', 15, 'VA', 15));
c = sfm_colores();
dE = p.AAE + 180 + p.RCE; dA = p.AAA + 180 + p.RCA;
aE = 180 - p.AAE; aA = 360 - p.AAA;
cb = p.RCE + p.AAA; cmax = (p.RCE + p.VE) + (p.AAA + p.VA); cmin = max(0, (p.RCE - p.VE) + (p.AAA - p.VA));
R = struct('dur_escape', dE, 'dur_admision', dA, 'cruce_base', cb, 'cruce_max', cmax, 'cruce_min', cmin, ...
    'compresion', 180 - p.RCA, 'expansion', 180 - p.AAE);
sfm_tabla('Distribución y cruce de válvulas', { ...
    'Duración de escape (°)', dE, '%.0f', 'AAE + 180 + RCE'; 'Duración de admisión (°)', dA, '%.0f', 'AAA + 180 + RCA'; ...
    'Duración de admisión en el árbol (°)', dA/2, '%.0f', 'el árbol gira a la mitad'; ...
    'Cruce base (°)', cb, '%.0f', 'RCE + AAA'; 'Cruce máximo (°)', cmax, '%.0f', 'escape retrasado + admisión adelantada'; ...
    'Cruce mínimo (°)', cmin, '%.0f', 'escape adelantado + admisión retrasada'; ...
    'Compresión efectiva (°)', 180 - p.RCA, '%.0f', '180 − RCA'; 'Expansión útil (°)', 180 - p.AAE, '%.0f', '180 − AAE'; ...
    'Comprobación: suma de fases − cruce (°)', dA + (180 - p.RCA) + (180 - p.AAE) + dE - cb, '%.0f', 'debe ser 720'});
th = 0:0.5:720;
sfm_fig('Cruce de válvulas', 1200, 520);
subplot(1,2,1); hold on
plot(th, u3_alzada_valvula(th, aE - p.VE, dE, p.HE, p.rampa), ':', 'Color', c.rojo, 'LineWidth', 1.2);
plot(th, u3_alzada_valvula(th, aE, dE, p.HE, p.rampa), '-', 'Color', c.rojo, 'LineWidth', 2);
plot(th, u3_alzada_valvula(th, aE + p.VE, dE, p.HE, p.rampa), '--', 'Color', c.rojo, 'LineWidth', 1.2);
plot(th, u3_alzada_valvula(th, aA - p.VA, dA, p.HA, p.rampa), ':', 'Color', c.azul, 'LineWidth', 1.2);
plot(th, u3_alzada_valvula(th, aA, dA, p.HA, p.rampa), '-', 'Color', c.azul, 'LineWidth', 2);
plot(th, u3_alzada_valvula(th, aA + p.VA, dA, p.HA, p.rampa), '--', 'Color', c.azul, 'LineWidth', 1.2);
for x = [0 180 360 540 720], plot([x x], [0 1.15*max(p.HE, p.HA)], 'k:', 'HandleVisibility', 'off'); end
lab = {'PMS', 'PMI', 'PMS', 'PMI', 'PMS'}; xs = [0 180 360 540 720];
for k = 1:5, text(xs(k), 1.18*max(p.HE, p.HA), lab{k}, 'HorizontalAlignment', 'center', 'FontSize', 8); end
xlim([0 720]); set(gca, 'XTick', 0:90:720); grid on; xlabel('Ángulo del cigüeñal (°)'); ylabel('Alzada (mm)')
legend('Esc. adelantado', 'Escape base', 'Esc. retrasado', 'Adm. adelantada', 'Admisión base', 'Adm. retrasada', 'Location', 'northwest')
title(sprintf('Alzado de las válvulas · cruce %g° (mín %g°, máx %g°)', cb, cmin, cmax))
subplot(1,2,2); hold on; axis equal; axis off
local_arco(-p.AAA, 180 + p.RCA, 1.0, c.azul, 6);
local_arco(180 - p.AAE, 360 + p.RCE, 0.82, c.rojo, 6);
t = linspace(0, 2*pi, 200); plot(1.12*cos(t), 1.12*sin(t), 'Color', [0.8 0.8 0.8]);
plot([0 0], [-1.15 1.15], 'k--'); text(0, 1.25, 'PMS', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
text(0, -1.25, 'PMI', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
local_rotulo(-p.AAA, 1.05, sprintf('AAA %g°', p.AAA), c.azul); local_rotulo(180 + p.RCA, 1.05, sprintf('RCA %g°', p.RCA), c.azul);
local_rotulo(180 - p.AAE, 0.6, sprintf('AAE %g°', p.AAE), c.rojo); local_rotulo(p.RCE, 0.6, sprintf('RCE %g°', p.RCE), c.rojo);
text(0, 0, sprintf('cruce\n%g°', cb), 'HorizontalAlignment', 'center');
title('Diagrama circular (sentido horario)'); axis([-1.45 1.45 -1.4 1.4]);
sfm_titulo('Simulador del alzado de válvulas y del cruce');
end

function local_arco(a0, a1, r, col, w)
a = linspace(a0, a1, 200)*pi/180;
plot(r*sin(a), r*cos(a), 'Color', col, 'LineWidth', w);
end
function local_rotulo(a, r, txt, col)
a = a*pi/180; text(r*sin(a)*1.18, r*cos(a)*1.18, txt, 'Color', col, 'HorizontalAlignment', 'center', 'FontSize', 9, 'FontWeight', 'bold');
end
