function h = u3_alzada_valvula(theta, apertura, duracion, H, rampa)
%U3_ALZADA_VALVULA Perfil didáctico de alzada (flancos en coseno y meseta).
%   h = u3_alzada_valvula(theta, apertura, duracion, H, rampa)
%   theta     ángulo del cigüeñal (°), vector (0–720)
%   apertura  ángulo de apertura (°);  duracion  duración (°);  H alzada máx (mm)
%   rampa     fracción de la duración que ocupa cada flanco (0,10–0,50)
if nargin < 5, rampa = 0.42; end
u = mod(theta - apertura, 720)/duracion;
h = zeros(size(theta));
s = u > 0 & u < rampa;              h(s) = H*(1 - cos(pi*u(s)/rampa))/2;
s = u >= rampa & u <= 1 - rampa;    h(s) = H;
s = u > 1 - rampa & u < 1;          h(s) = H*(1 - cos(pi*(1 - u(s))/rampa))/2;
end
