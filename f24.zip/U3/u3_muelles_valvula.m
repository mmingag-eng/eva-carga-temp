function R = u3_muelles_valvula(p)
%U3_MUELLES_VALVULA Comprobación de los muelles de válvula (ley de Hooke).
%   R = u3_muelles_valvula(p)
%
%   Parámetros (estructura p):
%     L_libre, L_min, L_medida   longitud libre especificada, mínima y medida (mm) [45 43.8 44.5]
%     L_montaje                  altura de montaje, válvula cerrada (mm)          [38]
%     F_esp, F_med               fuerza especificada y medida a la altura de montaje (N) [230 214]
%     alzada                     alzada de la válvula (mm)                         [9]
%     L_solida                   altura sólida, espiras juntas (mm)                [26.5]
%     perp, perp_max             falta de perpendicularidad medida y máxima (mm)   [0.9 1.5]
%     perdida_max                pérdida de fuerza admisible (%)                   [10]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('L_libre', 45, 'L_min', 43.8, 'L_medida', 44.5, 'L_montaje', 38, 'F_esp', 230, 'F_med', 214, ...
    'alzada', 9, 'L_solida', 26.5, 'perp', 0.9, 'perp_max', 1.5, 'perdida_max', 10));
c = sfm_colores();
k1 = p.F_esp/(p.L_libre - p.L_montaje); k2 = p.F_med/(p.L_medida - p.L_montaje);
La = p.L_montaje - p.alzada; Fa1 = k1*(p.L_libre - La); Fa2 = k2*(p.L_medida - La);
perd = (1 - p.F_med/p.F_esp)*100; marg = La - p.L_solida;
v = [p.L_medida >= p.L_min, perd <= p.perdida_max, p.perp <= p.perp_max, marg >= 1];
txt = {'Longitud libre', 'Fuerza', 'Perpendicularidad', 'Bloqueo de espiras'};
R = struct('k_esp', k1, 'k_medido', k2, 'F_abierta_esp', Fa1, 'F_abierta_med', Fa2, 'perdida_pct', perd, 'margen_bloqueo', marg, 'apto', all(v));
sfm_tabla('Muelles de válvula', { ...
    'Rigidez especificada (N/mm)', k1, '%.1f', 'F/(L libre − L montaje)'; 'Rigidez del muelle medido (N/mm)', k2, '%.1f', ''; ...
    'Altura con la válvula abierta (mm)', La, '%.1f', ''; 'Fuerza especificada con la válvula abierta (N)', Fa1, '%.0f', ''; ...
    'Fuerza del muelle medido, válvula abierta (N)', Fa2, '%.0f', ''; 'Pérdida de fuerza (%)', perd, '%.1f', ''; ...
    'Margen hasta el bloqueo de espiras (mm)', marg, '%.1f', ''});
for i = 1:4, if v(i), s = 'Correcto'; else, s = 'NO CUMPLE'; end; fprintf('  %-20s %s\n', txt{i}, s); end
if all(v), fprintf('  Conclusión: el muelle puede volver a montarse.\n'); else, fprintf('  Conclusión: sustituir el muelle y comprobar los demás del juego.\n'); end
L = linspace(p.L_libre, p.L_solida, 60);
sfm_fig('Muelles de válvula', 850, 480);
plot(L, k1*(p.L_libre - L), 'Color', c.azul, 'LineWidth', 1.8); hold on
plot(L, k2*max(0, p.L_medida - L), 'Color', c.naranja, 'LineWidth', 1.8)
plot([p.L_montaje La], [p.F_esp Fa1], 'o', 'Color', c.azul, 'MarkerFaceColor', c.azul)
plot([p.L_montaje La], [p.F_med Fa2], 'd', 'Color', c.naranja, 'MarkerFaceColor', c.naranja)
set(gca, 'XDir', 'reverse'); grid on; xlabel('Longitud del muelle (mm)  (comprimido \rightarrow)'); ylabel('Fuerza (N)')
legend('Especificación', 'Muelle medido', 'Montaje/apertura (esp.)', 'Montaje/apertura (medido)', 'Location', 'northwest')
title('Fuerza del muelle según su longitud')
end
