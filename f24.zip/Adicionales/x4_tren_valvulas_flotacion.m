function R = x4_tren_valvulas_flotacion(p)
%X4_TREN_VALVULAS_FLOTACION Dinámica del tren de válvulas: aceleración, fuerzas y régimen de flotación.
%   R = x4_tren_valvulas_flotacion(p)
%
%   Leva de perfil cosenoidal: h(φ) = H·(1 − cos(2π·u))/2, u = φ/duración.
%   La aceleración de la válvula es a = h''(φ)·ω_leva², con ω_leva = 2π·(n/2)/60.
%   Fuerza de contacto leva–taqué: Fc = F_montaje + k·h + m_eq·a.
%   Si Fc < 0 la válvula deja de seguir a la leva (flotación).
%
%   Parámetros (estructura p):
%     H           alzada máxima de la válvula (mm)                 [9]
%     duracion    duración de la apertura (° de cigüeñal)          [240]
%     m_eq        masa equivalente: válvula + platillo + chavetas
%                 + 1/3 del muelle + taqué (g)                     [120]
%     k           rigidez del muelle (N/mm)                         [32.9]
%     F_montaje   fuerza del muelle con la válvula cerrada (N)     [230]
%     n           régimen de estudio (rpm)                          [6500]
%   Use los valores medidos en u3_muelles_valvula para k y F_montaje.
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('H', 9, 'duracion', 240, 'm_eq', 120, 'k', 32.9, 'F_montaje', 230, 'n', 6500));
c = sfm_colores();
Dc = p.duracion/2*pi/180;                         % duración en radianes de leva
u = linspace(0, 1, 721); phi = u*p.duracion;      % ° de cigüeñal
h = p.H*(1 - cos(2*pi*u))/2;                      % mm
d2h = p.H/1000*(2*pi)^2/2*cos(2*pi*u)/Dc^2;       % m/rad²
wl = @(n) 2*pi*(n/2)/60;
m = p.m_eq/1000;
Fc = @(n) p.F_montaje + p.k*h + m*d2h*wl(n)^2;
% régimen de flotación: mínimo de Fc = 0 (en la nariz, u = 0,5)
anose = p.H/1000*(2*pi)^2/2/Dc^2;                 % |h''| en la nariz
nf = 60/pi*sqrt((p.F_montaje + p.k*p.H)/(m*anose));
a = d2h*wl(p.n)^2;
R = struct('a_max', max(a), 'a_min', min(a), 'Fc_min', min(Fc(p.n)), 'n_flotacion', nf, 'margen_pct', (nf/p.n - 1)*100);
sfm_tabla(sprintf('Tren de válvulas a %d rpm', p.n), { ...
    'Aceleración máxima de apertura (m/s²)', max(a), '%.0f', ''; 'Desaceleración en la nariz (m/s²)', min(a), '%.0f', ''; ...
    'Fuerza del muelle en la nariz (N)', p.F_montaje + p.k*p.H, '%.0f', 'F_montaje + k·H'; ...
    'Fuerza de inercia en la nariz (N)', m*abs(min(a)), '%.0f', 'm_eq·|a|'; 'Fuerza de contacto mínima (N)', R.Fc_min, '%.0f', '> 0 para no flotar'; ...
    'Régimen de flotación (rpm)', nf, '%.0f', ''; 'Margen respecto al régimen estudiado (%)', R.margen_pct, '%.1f', ''});
if R.Fc_min < 0, fprintf('  ¡FLOTACIÓN! La válvula se separa de la leva: riesgo de choque con el pistón.\n'); end
sfm_fig('Tren de válvulas', 1150, 600);
subplot(2,2,1); plot(phi, h, 'Color', c.azul, 'LineWidth', 1.8); grid on; xlabel('Ángulo de cigüeñal desde la apertura (°)'); ylabel('h (mm)'); title('Alzada')
subplot(2,2,2); plot(phi, a/9.81, 'Color', c.morado, 'LineWidth', 1.8); grid on; xlabel('(°)'); ylabel('a (g)'); title(sprintf('Aceleración de la válvula a %d rpm', p.n))
subplot(2,2,3); plot(phi, p.F_montaje + p.k*h, 'Color', c.verde, 'LineWidth', 1.8); hold on; plot(phi, -m*a, 'Color', c.rojo, 'LineWidth', 1.8); plot(phi, Fc(p.n), 'k', 'LineWidth', 1.8)
plot(phi([1 end]), [0 0], 'k:'); grid on; xlabel('(°)'); ylabel('N'); legend('muelle', 'inercia (−m·a)', 'contacto', 'Location', 'southwest'); title('Fuerzas')
subplot(2,2,4); nn = 1000:250:12000; fm = arrayfun(@(n) min(Fc(n)), nn); plot(nn, fm, 'Color', c.naranja, 'LineWidth', 1.8); hold on
plot(nn([1 end]), [0 0], 'r--'); plot(nf, 0, 'ro', 'MarkerFaceColor', 'r'); grid on; xlabel('Régimen (rpm)'); ylabel('F contacto mínima (N)'); title(sprintf('Flotación a %.0f rpm', nf))
sfm_titulo('Dinámica del tren de válvulas: ¿por qué un muelle vencido limita las rpm?');
end
