function R = u4_balance_termico(p)
%U4_BALANCE_TERMICO Balance térmico del motor y caudal de refrigerante.
%   R = u4_balance_termico(p)
%
%   Parámetros (estructura p):
%     Pe       potencia efectiva (kW)                         [60]
%     mc       consumo de combustible (kg/h)                  [18]
%     PCI      poder calorífico inferior (MJ/kg)              [43.5]
%     f_esc    fracción al escape                             [0.33]
%     f_otras  fracción de otras pérdidas                     [0.08]
%     dT       salto de temperatura en el radiador (K)        [8]
%     cp       calor específico del refrigerante (kJ/kg·K)    [3.6]
%     rho      densidad del refrigerante (kg/L)               [1.06]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('Pe', 60, 'mc', 18, 'PCI', 43.5, 'f_esc', 0.33, 'f_otras', 0.08, 'dT', 8, 'cp', 3.6, 'rho', 1.06));
c = sfm_colores();
Q = p.mc*p.PCI*1000/3600; Qe = Q*p.f_esc; Qo = Q*p.f_otras; Qr = Q - p.Pe - Qe - Qo;
m = Qr/(p.cp*p.dT);
R = struct('Q', Q, 'eta', p.Pe/Q, 'ce', p.mc*1000/p.Pe, 'Q_escape', Qe, 'Q_otras', Qo, 'Q_refrig', Qr, 'm_kg_s', m, 'caudal_L_min', m/p.rho*60);
sfm_tabla('Balance térmico', { ...
    'Potencia del combustible (kW)', Q, '%.1f', 'ṁ·PCI'; 'Rendimiento efectivo (%)', R.eta*100, '%.1f', 'Pe/Q'; ...
    'Consumo específico (g/kWh)', R.ce, '%.0f', ''; 'Calor al escape (kW)', Qe, '%.1f', ''; 'Otras pérdidas (kW)', Qo, '%.1f', ''; ...
    'Calor a la refrigeración (kW)', Qr, '%.1f', 'lo que queda del balance'; 'Caudal de refrigerante (kg/s)', m, '%.2f', 'Q/(cp·ΔT)'; ...
    'Caudal de la bomba (L/min)', R.caudal_L_min, '%.0f', ''});
if Qr <= 0, fprintf('  Revise los datos: el balance no deja calor para la refrigeración.\n'); end
sfm_fig('Balance térmico', 1000, 450);
subplot(1,2,1); pie([p.Pe Qe max(Qr, 0) Qo], {'Trabajo', 'Escape', 'Refrigeración', 'Otras'}); title('Destino de la energía del combustible')
subplot(1,2,2); dts = 4:0.5:15; plot(dts, Qr./(p.cp*dts)/p.rho*60, 'Color', c.azul, 'LineWidth', 1.8); hold on
plot(p.dT, R.caudal_L_min, 'ko', 'MarkerFaceColor', 'y'); grid on; xlabel('\DeltaT en el radiador (K)'); ylabel('Caudal (L/min)'); title('Caudal necesario según el salto térmico')
end
