function R = u4_ovalizacion(p)
%U4_OVALIZACION Ovalización, conicidad y decisión de rectificado del bloque.
%   R = u4_ovalizacion(p)
%
%   Parámetros (estructura p):
%     D_nom        diámetro nominal (mm)                                   [74.00]
%     lecturas     matriz z×6: [Alta A, Alta B, Media A, Media B, Baja A, Baja B] (mm)
%                  A = paralelo al cigüeñal, B = perpendicular
%     oval_max, conic_max, desg_max   límites (mm)                          [0.05 0.05 0.10]
%     margen       material adicional para limpiar el desgaste (mm)         [0.05]
%     sobremedidas sobremedidas comerciales (mm)                            [0.25 0.50 0.75 1.00]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('D_nom', 74.00, 'lecturas', [74.02 74.03 74.01 74.02 74.00 74.01; 74.03 74.05 74.02 74.03 74.01 74.01; ...
    74.06 74.12 74.04 74.07 74.01 74.02; 74.03 74.04 74.02 74.03 74.01 74.01], 'oval_max', 0.05, 'conic_max', 0.05, ...
    'desg_max', 0.10, 'margen', 0.05, 'sobremedidas', [0.25 0.50 0.75 1.00]));
c = sfm_colores();
X = p.lecturas; z = size(X, 1);
oval = max(abs(X(:, [1 3 5]) - X(:, [2 4 6])), [], 2);
conic = max(abs(X(:, 1) - X(:, 5)), abs(X(:, 2) - X(:, 6)));
dmax = max(X, [], 2); desg = dmax - p.D_nom;
cumple = oval <= p.oval_max + 1e-9 & conic <= p.conic_max + 1e-9 & desg <= p.desg_max + 1e-9;
fprintf('\nOvalización y conicidad\n  Cil  Ovaliz.  Conic.  D máx    Desgaste  Estado\n');
for k = 1:z
    if cumple(k), s = 'Cumple'; else, s = 'Fuera de límite'; end
    fprintf('  %-4d %-8.3f %-7.3f %-8.2f %-9.3f %s\n', k, oval(k), conic(k), dmax(k), desg(k), s);
end
quitar = max(desg) + p.margen;
if all(cumple), dec = 'Bloque apto: no requiere rectificado (cambiar segmentos y bruñir si el manual lo indica).'; sm = 0;
else
    sm = p.sobremedidas(find(p.sobremedidas >= quitar - 1e-9, 1));
    if isempty(sm), dec = 'El desgaste supera la mayor sobremedida: encamisar el bloque.'; sm = NaN;
    else, dec = sprintf('Rectificar los %d cilindros a +%.2f mm (D = %.2f mm) y montar pistones y segmentos de esa medida.', z, sm, p.D_nom + sm); end
end
fprintf('  Material a retirar (desgaste + margen): %.2f mm\n  DECISIÓN: %s\n', quitar, dec);
R = struct('ovalizacion', oval, 'conicidad', conic, 'desgaste', desg, 'cumple', cumple, 'sobremedida', sm, 'decision', dec);
sfm_fig('Ovalización y conicidad', 1000, 450);
subplot(1,2,1); bar([oval conic desg]); grid on; hold on
plot([0.5 z + 0.5], [p.oval_max p.oval_max], 'k--'); plot([0.5 z + 0.5], [p.desg_max p.desg_max], 'r--')
xlabel('Cilindro'); ylabel('mm'); legend('Ovalización', 'Conicidad', 'Desgaste', 'Límite oval./conic.', 'Límite desgaste', 'Location', 'northwest'); title('Resultados por cilindro')
subplot(1,2,2); plot(X(:, [1 3 5])', [3 2 1], '-o', 'LineWidth', 1.4); hold on
set(gca, 'ColorOrderIndex', 1); plot(X(:, [2 4 6])', [3 2 1], '--s', 'LineWidth', 1.2)
set(gca, 'YTick', 1:3, 'YTickLabel', {'Baja', 'Media', 'Alta'}); grid on; xlabel('Diámetro (mm)'); title('Perfil del cilindro (— A, -- B)')
sfm_titulo(dec);
end
