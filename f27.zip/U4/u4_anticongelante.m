function R = u4_anticongelante(p)
%U4_ANTICONGELANTE Mezcla de anticongelante, punto de congelación y de ebullición.
%   R = u4_anticongelante(p)
%
%   Parámetros (estructura p):
%     capacidad   capacidad del circuito (L)                     [6.0]
%     deseada     concentración deseada (fracción 0–1)           [0.50]
%     actual      concentración actual medida (fracción)         [0.20]
%     tapon       presión de apertura del tapón (bar)            [1.1]
%     altitud     altitud del lugar (m) (Loja ≈ 2100)             [2100]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('capacidad', 6.0, 'deseada', 0.50, 'actual', 0.20, 'tapon', 1.1, 'altitud', 2100));
c = sfm_colores();
tab = [0 0 100; 0.1 -3.5 101; 0.2 -7.8 102; 0.3 -14 104; 0.4 -23 105; 0.5 -34 107; 0.6 -48 110; 0.7 -48 112];
Tc = interp1(tab(:,1), tab(:,2), p.deseada); dTe = interp1(tab(:,1), tab(:,3), p.deseada) - 100;
pa = 1.01325*(1 - 2.25577e-5*p.altitud)^5.25588;
teb = @(P) 1/(1/373.15 - 8.314/40650*log(P/1.01325)) - 273.15;     % Clausius-Clapeyron
conc = p.capacidad*p.deseada;
if p.deseada > p.actual, dren = p.capacidad*(p.deseada - p.actual)/(1 - p.actual); rep = 'anticongelante puro';
else, dren = p.capacidad*(p.actual - p.deseada)/p.actual; rep = 'agua desmineralizada'; end
R = struct('concentrado_L', conc, 'agua_L', p.capacidad - conc, 'drenar_L', dren, 'congelacion', Tc, ...
    'ebull_agua_abierto', teb(pa), 'ebull_mezcla_abierto', teb(pa) + dTe, 'ebull_mezcla_presion', teb(pa + p.tapon) + dTe);
sfm_tabla('Anticongelante', { ...
    'Concentrado para llenado nuevo (L)', conc, '%.1f', ''; 'Agua desmineralizada (L)', p.capacidad - conc, '%.1f', ''; ...
    'Para corregir: drenar (L)', dren, '%.1f', ['y reponer con ' rep]; 'Punto de congelación (°C)', Tc, '%.1f', 'tabla del etilenglicol'; ...
    'Presión atmosférica del lugar (bar)', pa, '%.3f', ''; 'Ebullición del agua, circuito abierto (°C)', R.ebull_agua_abierto, '%.1f', 'Clausius-Clapeyron'; ...
    'Ebullición de la mezcla, circuito abierto (°C)', R.ebull_mezcla_abierto, '%.1f', ''; ...
    'Ebullición de la mezcla presurizada (°C)', R.ebull_mezcla_presion, '%.1f', 'p atm + tapón'});
if p.deseada > 0.6, fprintf('  Atención: por encima del 60 %% la protección empeora.\n'); end
x = linspace(0, 0.6, 61);
sfm_fig('Anticongelante', 1000, 450);
subplot(1,2,1); plot(x*100, interp1(tab(:,1), tab(:,2), x), 'Color', c.azul, 'LineWidth', 1.8); hold on
plot(p.deseada*100, Tc, 'ko', 'MarkerFaceColor', 'y'); grid on; xlabel('Concentración (%)'); ylabel('°C'); title('Punto de congelación')
subplot(1,2,2); P = linspace(0.6, 2.6, 50); plot(P, arrayfun(teb, P) + dTe, 'Color', c.rojo, 'LineWidth', 1.8); hold on
plot([pa pa + p.tapon], [R.ebull_mezcla_abierto R.ebull_mezcla_presion], 'ko', 'MarkerFaceColor', 'y'); grid on
xlabel('Presión absoluta (bar)'); ylabel('°C'); title('Ebullición de la mezcla según la presión'); legend('mezcla', 'abierto / con tapón', 'Location', 'southeast')
end
