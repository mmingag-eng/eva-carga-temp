function R = u4_bomba_aceite(p)
%U4_BOMBA_ACEITE Bomba de aceite y válvula de descarga: caudal y presión según el régimen.
%   R = u4_bomba_aceite(p)
%
%   Parámetros (estructura p):
%     V            cilindrada de la bomba (cm³/rev)                     [8]
%     relacion     relación de giro bomba/cigüeñal                      [1.0]
%     etav         rendimiento volumétrico de la bomba nueva            [0.92]
%     desgaste     pérdida de caudal por desgaste de la bomba (%)       [0]
%     mu           viscosidad relativa del aceite: 0W-20 caliente 0,6 · 5W-30 caliente 0,8 ·
%                  15W-40 caliente 1,0 · 15W-40 a 40 °C 3,0 · 15W-40 a 20 °C 6,0   [1.0]
%     p_valvula    presión de apertura de la válvula de descarga (bar)  [4.5]
%     Rcirc        resistencia del circuito (bar por L/min)             [0.25]
%     holgura      aumento de holgura de los cojinetes (%)              [0]
%     n            régimen de análisis (rpm)                            [3000]
%     n_ralenti, p_min   ralentí (rpm) y presión mínima admisible (bar) [800 1.0]
%
%   Modelo laminar: p = R·μ·Q_real, con fugas internas de la bomba 0,3·p/μ (L/min).
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('V', 8, 'relacion', 1.0, 'etav', 0.92, 'desgaste', 0, 'mu', 1.0, 'p_valvula', 4.5, ...
    'Rcirc', 0.25, 'holgura', 0, 'n', 3000, 'n_ralenti', 800, 'p_min', 1.0));
c = sfm_colores();
Re = p.Rcirc/(1 + p.holgura/100)^3;
Qt = @(n) p.V*p.relacion*n/1000;
Qr = @(n) Qt(n)*p.etav*(1 - p.desgaste/100);
praw = @(n) Re*p.mu*Qr(n)/(1 + Re*0.3);
pc = @(n) min(praw(n), p.p_valvula);
Qc = @(n) pc(n)/(Re*p.mu);
by = max(0, Qr(p.n) - 0.3*pc(p.n)/p.mu - Qc(p.n));
R = struct('Q_teorico', Qt(p.n), 'p_sin_valvula', praw(p.n), 'p', pc(p.n), 'Q_cojinetes', Qc(p.n), 'Q_retorno', by, 'p_ralenti', pc(p.n_ralenti));
if praw(p.n) > p.p_valvula, vs = 'abierta (limitando)'; else, vs = 'cerrada'; end
sfm_tabla(sprintf('Bomba de aceite a %d rpm', p.n), { ...
    'Resistencia efectiva (bar por L/min)', Re, '%.3f', 'R/(1 + Δh)³'; 'Caudal teórico (L/min)', Qt(p.n), '%.1f', 'Q = V·n'; ...
    'Presión sin válvula (bar)', praw(p.n), '%.2f', ''; 'Presión en el circuito (bar)', pc(p.n), '%.2f', ['válvula ' vs]; ...
    'Caudal a los cojinetes (L/min)', Qc(p.n), '%.1f', 'p/(R·μ)'; 'Caudal que regresa por la válvula (L/min)', by, '%.1f', ''; ...
    'Presión en ralentí (bar)', R.p_ralenti, '%.2f', ''});
if R.p_ralenti < p.p_min, fprintf('  Presión baja en ralentí: se encenderá el testigo (aceite fluido, bomba o cojinetes desgastados).\n');
elseif p.mu >= 3, fprintf('  Aceite frío: la válvula abre pronto y llega poco caudal a los cojinetes; no acelere en frío.\n'); end
nn = 600:100:7000;
sfm_fig('Bomba de aceite', 1100, 450);
subplot(1,2,1); plot(nn, arrayfun(pc, nn), 'Color', c.naranja, 'LineWidth', 1.8); hold on
plot(nn([1 end]), [p.p_valvula p.p_valvula], 'r--'); plot(nn([1 end]), [p.p_min p.p_min], 'k:')
ylim([0 1.15*p.p_valvula]); grid on; xlabel('Régimen (rpm)'); ylabel('Presión (bar)'); legend('Presión en el circuito', 'Apertura de la válvula', 'Mínimo en ralentí', 'Location', 'southeast'); title('Presión de aceite')
subplot(1,2,2); plot(nn, arrayfun(Qr, nn), 'Color', c.azul, 'LineWidth', 1.8); hold on; plot(nn, arrayfun(Qc, nn), 'Color', c.verde, 'LineWidth', 1.8)
grid on; xlabel('Régimen (rpm)'); ylabel('Caudal (L/min)'); legend('Bomba', 'A los cojinetes', 'Location', 'northwest'); title('Caudal')
sfm_titulo(sprintf('Bomba de aceite · μ relativa = %g · desgaste bomba %g %% · holgura cojinetes +%g %%', p.mu, p.desgaste, p.holgura));
end
