function R = u4_ciguenal_plastigage(p)
%U4_CIGUENAL_PLASTIGAGE Medición del cigüeñal, holgura con Plastigage y medida de rectificado.
%   R = u4_ciguenal_plastigage(p)
%
%   Parámetros (estructura p):
%     D_bancada, D_biela   diámetros nominales (mm)                          [50 45]
%     tipo                 'B' bancada / 'M' muñequilla por fila             ['BBBBBMMMM']
%     lecturas             matriz n×4 [A sec1, B sec1, A sec2, B sec2] (mm)
%     plastigage           holgura leída por fila (mm)
%     oval_max, desg_max   límites (mm)                                       [0.010 0.025]
%     h_min, h_max, h_lim  holgura especificada mín., máx. y límite (mm)      [0.020 0.050 0.080]
%     margen               material mínimo para rectificar (mm)              [0.020]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('D_bancada', 50, 'D_biela', 45, 'tipo', 'BBBBBMMMM', ...
    'lecturas', [49.995 49.993 49.994 49.995; 49.990 49.982 49.988 49.985; 49.996 49.994 49.995 49.993; 49.994 49.995 49.993 49.994; ...
                 49.996 49.995 49.996 49.994; 44.994 44.993 44.995 44.994; 44.995 44.994 44.994 44.993; 44.970 44.958 44.968 44.962; 44.994 44.995 44.993 44.994], ...
    'plastigage', [0.035 0.060 0.040 0.045 0.030 0.040 0.090 0.070 0.015], 'oval_max', 0.010, 'desg_max', 0.025, ...
    'h_min', 0.020, 'h_max', 0.050, 'h_lim', 0.080, 'margen', 0.020));
c = sfm_colores();
X = p.lecturas; n = size(X, 1); us = [0.25 0.5 0.75 1.0];
u = zeros(n, 1); oval = u; con = u; desg = u; dec = cell(n, 1); nom = u; nb = 0; nm = 0; etiq = cell(n, 1);
fprintf('\nCigüeñal y Plastigage\n  Muñón        Dmín     Oval.   Conic.  Desg.   Holgura  Decisión\n');
for k = 1:n
    if p.tipo(k) == 'B', nom(k) = p.D_bancada; nb = nb + 1; etiq{k} = sprintf('B%d', nb);
    else, nom(k) = p.D_biela; nm = nm + 1; etiq{k} = sprintf('M%d', nm); end
    dmin = min(X(k, :)); oval(k) = max(abs(X(k,1) - X(k,2)), abs(X(k,3) - X(k,4)));
    con(k) = max(abs(X(k,1) - X(k,3)), abs(X(k,2) - X(k,4))); desg(k) = nom(k) - dmin;
    geo = oval(k) <= p.oval_max + 1e-9 && con(k) <= p.oval_max + 1e-9 && desg(k) <= p.desg_max + 1e-9;
    h = p.plastigage(k);
    if ~geo
        i = find(nom(k) - us <= dmin - p.margen + 1e-9, 1);
        if isempty(i), u(k) = 9; dec{k} = 'Sustituir cigüeñal'; else, u(k) = us(i); dec{k} = sprintf('Rectificar a −%.2f mm', us(i)); end
    elseif h > p.h_lim, dec{k} = 'Cambiar cojinetes y volver a medir';
    elseif h > p.h_max, dec{k} = 'Holgura alta: cojinetes nuevos STD';
    elseif h < p.h_min, dec{k} = 'Holgura baja: revisar cojinete y medición';
    else, dec{k} = 'Correcto'; end
    fprintf('  %-12s %-8.3f %-7.3f %-7.3f %-7.3f %-8.3f %s\n', etiq{k}, dmin, oval(k), con(k), desg(k), h, dec{k});
end
ub = max(u(p.tipo == 'B')); um = max(u(p.tipo == 'M'));
fprintf('  Apoyos de bancada: %s  ·  Muñequillas de biela: %s\n', local_med(ub), local_med(um));
fprintf('  (B = apoyo de bancada, M = muñequilla de biela)\n');
fprintf('  Plastigage: verde 0,025–0,076 mm · rojo 0,051–0,152 mm · azul 0,102–0,229 mm\n');
R = struct('ovalizacion', oval, 'conicidad', con, 'desgaste', desg, 'decision', {dec}, 'rectif_bancada', ub, 'rectif_biela', um);
sfm_fig('Cigüeñal y Plastigage', 1100, 450);
subplot(1,2,1); bar([oval con desg]); hold on; plot([0.5 n + 0.5], [p.desg_max p.desg_max], 'r--'); plot([0.5 n + 0.5], [p.oval_max p.oval_max], 'k--')
set(gca, 'XTick', 1:n, 'XTickLabel', etiq); grid on; ylabel('mm'); legend('Ovalización', 'Conicidad', 'Desgaste', 'Lím. desgaste', 'Lím. oval.', 'Location', 'northwest'); title('Geometría de los muñones')
subplot(1,2,2); bar(p.plastigage, 'FaceColor', c.azul); hold on
plot([0.5 n + 0.5], [p.h_min p.h_min], 'g--'); plot([0.5 n + 0.5], [p.h_max p.h_max], 'g--'); plot([0.5 n + 0.5], [p.h_lim p.h_lim], 'r--')
set(gca, 'XTick', 1:n, 'XTickLabel', etiq); grid on; ylabel('Holgura (mm)'); title('Holgura de aceite (Plastigage)')
end

function s = local_med(u)
if u == 0, s = 'STD (no requiere)'; elseif u == 9, s = 'sustituir el cigüeñal'; else, s = sprintf('rectificar a −%.2f mm', u); end
end
