function R = x5_calentamiento_termostato(p)
%X5_CALENTAMIENTO_TERMOSTATO Calentamiento del motor con termostato y electroventilador (ecuación diferencial).
%   R = x5_calentamiento_termostato(p)
%
%   Modelo de dos nodos (motor + refrigerante y radiador) resuelto con ode45:
%     C_m·dTm/dt = Q_motor − ṁ(Tm)·cp·(Tm − Tr)
%     C_r·dTr/dt = ṁ(Tm)·cp·(Tm − Tr) − UA(v, ventilador)·(Tr − T_aire)
%   El caudal hacia el radiador crece con la apertura del termostato (lineal
%   entre T_abre y T_total). El ventilador se conecta progresivamente entre T_vent_off y T_vent_on.
%
%   Parámetros (estructura p):
%     t_final       tiempo simulado (s)                              [1500]
%     Q_ralenti     calor al refrigerante en ralentí (kW)            [6]
%     Q_carga       calor al refrigerante en carga (kW)              [35]
%     t_carga       instante en que empieza la carga en carretera (s) [300]
%     Q_trafico     calor en tráfico lento o subida a baja velocidad (kW) [15]
%     t_trafico     instante en que empieza el tráfico lento (s)     [1000]
%     T_aire        temperatura ambiente (°C)                        [18]
%     T_abre, T_total  inicio y plena apertura del termostato (°C)   [88 100]
%     T_vent_on, T_vent_off  ventilador (°C)                         [98 93]
%     falla         'ninguna' | 'termostato_abierto' | 'termostato_cerrado' | 'ventilador'   ['ninguna']
%     comparar      true: dibuja las cuatro situaciones juntas        [true]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('t_final', 1500, 'Q_ralenti', 6, 'Q_carga', 35, 't_carga', 300, 'Q_trafico', 15, 't_trafico', 1000, 'T_aire', 18, 'T_abre', 88, ...
    'T_total', 100, 'T_vent_on', 98, 'T_vent_off', 93, 'falla', 'ninguna', 'comparar', true));
c = sfm_colores();
casos = {p.falla};
if p.comparar, casos = {'ninguna', 'termostato_abierto', 'termostato_cerrado', 'ventilador'}; end
col = {c.verde, c.azul, c.rojo, c.naranja};
nom = struct('ninguna', 'Sistema correcto', 'termostato_abierto', 'Termostato pegado abierto', ...
             'termostato_cerrado', 'Termostato pegado cerrado', 'ventilador', 'Ventilador averiado');
sfm_fig('Calentamiento y termostato', 1150, 500);
subplot(1,2,1); hold on
for i = 1:numel(casos)
    [t, Tm, ab] = local_sim(p, casos{i});
    plot(t/60, Tm, 'Color', col{i}, 'LineWidth', 1.8);
    if i == 1, R = struct('t', t, 'T_motor', Tm, 'apertura', ab); end
    k90 = find(Tm >= 85, 1); if isempty(k90), t90 = NaN; else, t90 = t(k90)/60; end
    fprintf('  %-28s T final %6.1f °C · T máx %6.1f °C · llega a 85 °C en %5.1f min\n', nom.(casos{i}), Tm(end), max(Tm), t90);
    if max(Tm) > 125, fprintf('      supera 125 °C: el refrigerante hierve y se pierde; en la realidad el motor se dañaría (junta de culata, gripado).\n'); end
    R.resumen.(casos{i}) = [Tm(end) max(Tm) t90];
end
plot([0 p.t_final/60], [p.T_abre p.T_abre], 'k:'); plot([0 p.t_final/60], [110 110], 'r--'); ylim([0 140])
for tx = [p.t_carga p.t_trafico], plot([tx tx]/60, [0 140], 'k:', 'HandleVisibility', 'off'); end
grid on; xlabel('Tiempo (min)'); ylabel('Temperatura del motor (°C)'); title('Calentamiento del motor')
lg = cellfun(@(s) nom.(s), casos, 'UniformOutput', false); legend(lg, 'Location', 'southeast')
subplot(1,2,2); plot(R.t/60, R.apertura*100, 'Color', c.morado, 'LineWidth', 1.8); grid on
xlabel('Tiempo (min)'); ylabel('Apertura del termostato (%)'); title(['Apertura del termostato · ' nom.(casos{1})])
sfm_titulo(sprintf('Ralentí → carretera (%g kW) desde %g s → tráfico lento (%g kW) desde %g s', p.Q_carga, p.t_carga, p.Q_trafico, p.t_trafico));
end

function [t, Tm, ab] = local_sim(p, falla)
op = odeset('MaxStep', 2);
[t, Y] = ode45(@(tt, y) local_f(tt, y, p, falla), [0 p.t_final], [p.T_aire; p.T_aire], op);
Tm = Y(:, 1); ab = arrayfun(@(T) local_apertura(T, p, falla), Tm);
end

function a = local_apertura(T, p, falla)
switch falla
    case 'termostato_abierto', a = 1;
    case 'termostato_cerrado', a = 0;
    otherwise, a = min(1, max(0, (T - p.T_abre)/(p.T_total - p.T_abre)));
end
end

function dy = local_f(tt, y, p, falla)
Cm = 60e3; Cr = 12e3;                 % J/K: motor + refrigerante, radiador + líquido
cp = 3600; mmax = 1.2;                % J/kg·K; kg/s con el termostato abierto
mbyp = 0.02;                          % kg/s de fuga hacia el radiador con el termostato cerrado
UAv = 700; UAf = 450;                 % W/K del radiador en marcha y del ventilador
enmarcha = tt >= p.t_carga && tt < p.t_trafico;
if tt < p.t_carga, Q = p.Q_ralenti*1000; elseif enmarcha, Q = p.Q_carga*1000; else, Q = p.Q_trafico*1000; end
vent = min(1, max(0, (y(1) - p.T_vent_off)/(p.T_vent_on - p.T_vent_off)));   % conexión progresiva
if strcmp(falla, 'ventilador'), vent = 0; end
UA = UAv*(0.2 + 0.8*enmarcha) + UAf*vent;
m = mbyp + mmax*local_apertura(y(1), p, falla);
dy = [(Q - m*cp*(y(1) - y(2)))/Cm; (m*cp*(y(1) - y(2)) - UA*(y(2) - p.T_aire))/Cr];
end
