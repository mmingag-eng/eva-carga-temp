function p = sfm_param(p, def)
%SFM_PARAM Combina los parámetros del usuario con los valores por defecto.
%   p = sfm_param(p, def) devuelve la estructura def con los campos que el
%   usuario haya definido en p. Avisa si un campo no existe (error de tipeo).
if nargin < 1 || isempty(p), p = struct(); end
campos = fieldnames(def);
for k = 1:numel(campos)
    if ~isfield(p, campos{k}), p.(campos{k}) = def.(campos{k}); end
end
extra = setdiff(fieldnames(p), campos);
for k = 1:numel(extra)
    warning('SFM:parametro', 'El parámetro "%s" no existe en este simulador y se ignora.', extra{k});
end
end
