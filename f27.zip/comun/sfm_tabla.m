function sfm_tabla(titulo, filas)
%SFM_TABLA Imprime una tabla de resultados en la ventana de comandos.
%   filas = {etiqueta, valor, formato, nota; ...}
fprintf('\n%s\n%s\n', titulo, repmat('-', 1, max(20, numel(titulo))));
for k = 1:size(filas, 1)
    v = filas{k, 2};
    if ischar(v)
        s = v;
    else
        fmt = '%.4g';
        if size(filas, 2) >= 3 && ~isempty(filas{k, 3}), fmt = filas{k, 3}; end
        s = sprintf(fmt, v);
    end
    nota = '';
    if size(filas, 2) >= 4 && ~isempty(filas{k, 4}), nota = ['   <- ' filas{k, 4}]; end
    fprintf('  %-52s %14s%s\n', filas{k, 1}, s, nota);
end
end
