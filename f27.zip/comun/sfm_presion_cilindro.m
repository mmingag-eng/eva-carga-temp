function C = sfm_presion_cilindro(p)
%SFM_PRESION_CILINDRO Presión en el cilindro con la ley de combustión de Wiebe (modelo de una zona).
%   C = sfm_presion_cilindro(p) integra, desde el cierre de la admisión hasta la
%   apertura del escape, la ecuación
%       dp/dθ = (γ−1)/V·dQ/dθ − γ·p/V·dV/dθ
%   con la fracción quemada de Wiebe xb = 1 − exp(−a·((θ−θi)/Δθ)^(m+1)).
%   θ = 0° es el PMS de combustión (−180° PMI de admisión, +180° PMI de expansión).
%
%   Campos de p (todos con valor por defecto): D, S, L (mm), Rc, n (rpm),
%   p_adm (bar), T_adm (K), lambda, etav, avance (° antes del PMS), duracion (°),
%   a_w, m_w, gamma, PCI (MJ/kg), eta_comb, AFR_esteq, perdida_calor (fracción del
%   calor liberado que pasa a las paredes; modelo simplificado), paso (°).
def = struct('D', 86, 'S', 86, 'L', 145, 'Rc', 10, 'n', 3000, 'p_adm', 0.80, 'T_adm', 320, 'lambda', 1.0, ...
    'etav', 0.85, 'avance', 20, 'duracion', 55, 'a_w', 5, 'm_w', 2, 'gamma', 1.30, 'PCI', 43.5, ...
    'eta_comb', 0.95, 'AFR_esteq', 14.7, 'perdida_calor', 0.25, 'paso', 0.25);
if nargin < 1, p = struct(); end
f = fieldnames(def);
for k = 1:numel(f), if ~isfield(p, f{k}), p.(f{k}) = def.(f{k}); end, end
A = pi/4*(p.D/1000)^2; r = p.S/2000; Lb = p.L/1000; lam = r/Lb;
Vd = A*p.S/1000; Vc = Vd/(p.Rc - 1);
V = @(th) Vc + A*(r*(1 - cosd(th)) + Lb*(1 - sqrt(1 - lam^2*sind(th).^2)));
dV = @(th) A*r*(sind(th) + lam*sind(2*th)./(2*sqrt(1 - lam^2*sind(th).^2)))*pi/180;
rho = p.p_adm*1e5/(287*p.T_adm);
ma = rho*Vd*p.etav; mf = ma/(p.AFR_esteq*p.lambda);
Q = mf*p.PCI*1e6*p.eta_comb;                      % J por ciclo y cilindro
Qn = Q*(1 - p.perdida_calor);                     % calor que eleva la presión del gas
thi = -p.avance;
xb = @(th) (th > thi).*(1 - exp(-p.a_w*max(0, (th - thi)/p.duracion).^(p.m_w + 1)));
dxb = @(th) (th > thi).*p.a_w*(p.m_w + 1)/p.duracion.*max(0, (th - thi)/p.duracion).^p.m_w ...
            .*exp(-p.a_w*max(0, (th - thi)/p.duracion).^(p.m_w + 1));
th = -180:p.paso:180;
P = zeros(size(th)); P(1) = p.p_adm*1e5;
g = p.gamma;
fdp = @(t, pp) (g - 1)./V(t).*Qn.*dxb(t) - g*pp./V(t).*dV(t);
for i = 1:numel(th) - 1                           % Runge-Kutta de 4.º orden
    h = th(i+1) - th(i); t = th(i); y = P(i);
    k1 = fdp(t, y); k2 = fdp(t + h/2, y + h/2*k1); k3 = fdp(t + h/2, y + h/2*k2); k4 = fdp(t + h, y + h*k3);
    P(i+1) = y + h/6*(k1 + 2*k2 + 2*k3 + k4);
end
Vth = V(th);
Wexp = trapz(Vth, P);                             % trabajo de compresión + expansión (J)
C = struct('theta', th, 'p_bar', P/1e5, 'V', Vth, 'xb', xb(th), 'Vd', Vd, 'Vc', Vc, 'Q', Q, 'W', Wexp, ...
    'pmi_bar', Wexp/Vd/1e5, 'A', A, 'r', r, 'lam', lam, 'mf', mf);
[C.pmax_bar, k] = max(C.p_bar); C.theta_pmax = th(k);
end
