function sfm_linea(eje, valor, estilo, etiqueta)
%SFM_LINEA Dibuja una línea de referencia vertical ('x') u horizontal ('y').
%   Equivale a xline/yline y funciona también en Octave.
if nargin < 3 || isempty(estilo), estilo = 'k--'; end
hold on
lim = axis;
if eje == 'x'
    plot([valor valor], lim(3:4), estilo, 'HandleVisibility', 'off');
    if nargin > 3, text(valor, lim(4), [' ' etiqueta], 'VerticalAlignment', 'top', 'FontSize', 8); end
else
    plot(lim(1:2), [valor valor], estilo, 'HandleVisibility', 'off');
    if nargin > 3, text(lim(2), valor, [etiqueta ' '], 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom', 'FontSize', 8); end
end
axis(lim);
end
