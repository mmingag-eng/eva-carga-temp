function sfm_titulo(texto)
%SFM_TITULO Título general de la figura (equivale a sgtitle, compatible con Octave).
hs = findobj(gcf, 'Type', 'axes');
for k = 1:numel(hs)                         % deja espacio para el título general
    ps = get(hs(k), 'Position'); set(hs(k), 'Position', [ps(1), ps(2)*0.93, ps(3), ps(4)*0.93]);
end
ax = axes('Position', [0 0.955 1 0.04], 'Visible', 'off');
text(0.5, 0.5, texto, 'Parent', ax, 'HorizontalAlignment', 'center', ...
     'FontWeight', 'bold', 'FontSize', 12, 'Color', [0.12 0.23 0.37]);
end
