function h = sfm_fig(nombre, ancho, alto)
%SFM_FIG Crea una figura con el formato común de los simuladores SFM.
if nargin < 2, ancho = 1100; end
if nargin < 3, alto = 650; end
h = figure('Name', ['SFM · ' nombre], 'NumberTitle', 'off', 'Color', 'w');
pos = get(h, 'Position');
set(h, 'Position', [pos(1) pos(2) ancho alto]);
end
