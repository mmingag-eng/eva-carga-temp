function c = sfm_colores()
%SFM_COLORES Paleta común (azul, naranja, verde, rojo, morado, gris, dorado).
c.azul = [0.12 0.31 0.85]; c.naranja = [0.91 0.31 0.12]; c.verde = [0.18 0.62 0.27];
c.rojo = [0.84 0.19 0.12]; c.morado = [0.48 0.18 0.66]; c.gris = [0.55 0.55 0.55];
c.dorado = [0.72 0.53 0.04]; c.negro = [0 0 0];
end
