# Simuladores en MATLAB · Sistemas del Funcionamiento del Motor (MA.02.06, ISTS)

Versión MATLAB de los simuladores de los libros `SFM_Simuladores_U1…U4.xlsx`. Incluye además cinco simulaciones que no se pueden hacer en Excel.

## Cómo usarlos

1. Abra MATLAB (R2020a o posterior) o GNU Octave (7 o posterior) en esta carpeta.
2. Escriba `SFM_menu` y elija un número: el simulador se ejecuta con los datos de ejemplo, muestra los resultados en la ventana de comandos y dibuja sus gráficos.
3. Para cambiar los datos, llame al simulador con una estructura. Solo se escriben los campos que se quieren cambiar:

```matlab
u1_trucaje(struct('medida', 40, 'cepillado', 0.30))
u1_pie_de_rey(struct('sistema', 'pulg', 'resolucion', 1/128, 'ejercicio', 5, 'mostrar_solucion', false))
u2_oscilograma(struct('examen', true, 'ejercicio', 3))          % falla oculta
u2_oscilograma(struct('examen', true, 'ejercicio', 3, 'respuesta', 4))
u4_bomba_aceite(struct('mu', 6, 'n', 800))                      % aceite frío en ralentí
u1_orden_encendido_motores(struct('listar', true))               % lista de los 24 motores
u1_orden_encendido_motores(struct('config', 'cruciforme', 'animar', true))
u1_orden_encendido_motores(struct('orden', [1 2 4 3], 'theta', 180))
R = u3_cruce_valvulas(struct('AAA', 20, 'RCE', 20));             % R guarda todos los resultados
```

4. `help nombre_del_simulador` muestra la lista de parámetros, sus unidades y sus valores por defecto.
5. `SFM_prueba_todos` ejecuta todos los simuladores y guarda las figuras en la carpeta `figuras` (sirve para comprobar la instalación).

## Contenido

| Unidad | Archivo | Qué simula |
|---|---|---|
| I | `u1_biela_manivela` | Desplazamiento, velocidad, aceleración y fuerza de inercia del pistón |
| I | `u1_cilindrada_rc` | Cilindrada, relación de compresión, cepillado y sobremedida |
| I | `u1_curvas_par_potencia` | Curvas de par, potencia y consumo; corrección por altitud (DIN 70020) |
| I | `u1_trucaje` | Sobremedida «10, 20…», carrera, cepillado y junta según la Tabla 2 de la guía |
| I | `u1_ciclo_otto` | Ciclo Otto teórico y real, rendimiento y pmi |
| I | `u1_orden_encendido` | Fases de cada cilindro, válvulas y tablas de calibración (cruce y dos vueltas); `'animar', true` |
| I | `u1_orden_encendido_motores` | Orden de encendido de 24 motores (1 a 12 cilindros: en línea, V, VR, bóxer y radiales) u orden personalizado: división del ciclo, intervalos, muñequillas de frente y de lado, esquema, diagrama de fases, cilindros en expansión y cigüeñal en 3D que gira con θ |
| I | `u1_pie_de_rey`, `u1_micrometro`, `u1_reloj_comparador`, `u1_alexometro` | Lecturas en mm y pulgadas con ejercicios aleatorios, autocorrección y solución |
| II | `u2_dwell_bobina` | Dwell, corriente y energía de la bobina |
| II | `u2_curva_avance` | Avance centrífugo y por vacío |
| II | `u2_lambda_gases` | λ y gases de escape |
| II | `u2_venturi` | Depresión en el difusor (Bernoulli) y riqueza del carburador elemental |
| II | `u2_oscilograma` | Oscilograma del secundario con 6 fallas y modo examen |
| III | `u3_cruce_valvulas` | Alzado de válvulas, cruce base/máximo/mínimo y diagrama circular |
| III | `u3_salto_dientes` | Desfase por diente y compresión efectiva |
| III | `u3_levas_superpuestas` | Perfil de las levas y LSA; `'girar', true` anima el árbol |
| III | `u3_pastillas` | Reglaje con pastillas calibradas |
| III | `u3_apriete_culata` | Secuencia de apriete/aflojado y control de la práctica |
| III | `u3_muelles_valvula` | Comprobación de muelles (Hooke) |
| IV | `u4_ovalizacion` | Ovalización, conicidad y sobremedida del bloque |
| IV | `u4_anticongelante` | Mezcla, congelación y ebullición en altura |
| IV | `u4_balance_termico` | Balance térmico y caudal de refrigerante |
| IV | `u4_ciguenal_plastigage` | Muñones, Plastigage y medida de rectificado |
| IV | `u4_bomba_aceite` | Caudal, presión y válvula de descarga |

### Simulaciones adicionales (solo MATLAB)

| Archivo | Qué simula | Unidad |
|---|---|---|
| `x1_animacion_4tiempos` | Animación del ciclo de cuatro tiempos con biela-manivela, válvulas, cruce y chispa. Con `'gif', 'ciclo.gif'` guarda un GIF para las diapositivas o el EVA. | I y III |
| `x2_combustion_wiebe` | Presión en el cilindro con la ley de combustión de Wiebe, fracción quemada, pmi y avance de máximo par (MBT) | I y II |
| `x3_par_instantaneo_volante` | Par de gases e inercia en el cigüeñal, par total con 1–8 cilindros, fluctuación del régimen y volante necesario | I y IV |
| `x4_tren_valvulas_flotacion` | Aceleración de la válvula, fuerza del muelle frente a la inercia y régimen de flotación | III |
| `x5_calentamiento_termostato` | Calentamiento del motor (ecuación diferencial con `ode45`): termostato normal, pegado abierto, pegado cerrado y ventilador averiado | IV |

## Actividades sugeridas

- **Trucaje (U1):** ¿qué junta hay que montar y qué relación de compresión queda si se rectifica a «40» y se cepillan 0,4 mm?
- **Ciclo Otto (U1):** compare `p1 = 1.033` con `p1 = 0.80` (Loja) y explique la pérdida de potencia en altura.
- **Orden de encendido (U1):** compare el V8 cruciforme con el V8 plano: ¿por qué tienen el mismo intervalo de 90° pero cigüeñales distintos? Observe en el diagrama de fases cuántos cilindros hay en expansión en un 3, un 4 y un 6 cilindros.
- **Metrología (U1):** genere 10 ejercicios con `mostrar_solucion = false` y corríjalos con `respuesta`.
- **Wiebe (adicional):** varíe el avance entre 0 y 45° y relacione la presión máxima con el picado.
- **Flotación (adicional):** use la rigidez del muelle medido en `u3_muelles_valvula` y compruebe hasta qué régimen sigue la válvula a la leva.
- **Termostato (adicional):** relacione cada curva con un síntoma real: el motor no calienta, se recalienta en el tráfico o hierve.

## Notas

- Son modelos didácticos simplificados: no sustituyen los datos ni los procedimientos del fabricante.
- Los resultados se imprimen con punto decimal (formato de MATLAB).
- `comun/` contiene funciones auxiliares (`sfm_param`, `sfm_tabla`, `sfm_presion_cilindro`…), que no se ejecutan por separado.
- Se probó con GNU Octave 8.4; el código usa solo funciones básicas, disponibles también en MATLAB.
