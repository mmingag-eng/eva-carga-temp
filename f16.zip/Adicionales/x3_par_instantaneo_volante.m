function R = x3_par_instantaneo_volante(p)
%X3_PAR_INSTANTANEO_VOLANTE Par instantáneo del cigüeñal (gases + inercia) y dimensionado del volante.
%   R = x3_par_instantaneo_volante(p)
%
%   El par de cada cilindro se obtiene de la fuerza sobre el pistón
%   F = (p − p_cárter)·A − m_alt·a  y de la geometría biela-manivela:
%   M = F·r·(sen θ + λ·sen 2θ / (2·√(1 − λ²·sen²θ))).
%   Los cilindros se desfasan 720°/z (encendidos equidistantes).
%   El coeficiente de irregularidad es δ = ΔE/(I·ω²).
%
%   Parámetros (estructura p):
%     z          número de cilindros                     [4]
%     n          régimen (rpm)                           [3000]
%     m_alt      masa alternativa por cilindro (kg)      [0.55]
%     I_volante  momento de inercia total (kg·m²)        [0.12]
%     delta_obj  irregularidad objetivo (1/δ)            [150]
%     motor      estructura con los datos de sfm_presion_cilindro (D, S, L, Rc, avance…)
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('z', 4, 'n', 3000, 'm_alt', 0.55, 'I_volante', 0.12, 'delta_obj', 150, 'motor', struct()));
c = sfm_colores();
mot = p.motor; mot.n = p.n;
C = sfm_presion_cilindro(mot);
th = -360:0.5:359.5;                              % ciclo completo de un cilindro
pg = interp1(C.theta, C.p_bar, th, 'linear', NaN);
pg(isnan(pg)) = 1.0;                              % escape y admisión ≈ 1 bar
pg(th > 180 | th < -180) = 1.05; pg(th >= -360 & th < -180) = 0.95;
w = 2*pi*p.n/60; r = C.r; lam = C.lam;
s = sind(th); cs = cosd(th);
k = s + lam*sind(2*th)./(2*sqrt(1 - lam^2*s.^2));
acc = r*w^2*(cs + lam*cosd(2*th));
Mg = (pg - 1)*1e5*C.A*r.*k;                       % par de los gases (N·m)
Mi = -p.m_alt*acc*r.*k;                           % par de las fuerzas de inercia
M1 = Mg + Mi;
Mt = zeros(size(th));
for j = 0:p.z - 1
    Mt = Mt + circshift(M1, [0, round(j*720/p.z/0.5)]);
end
Mm = mean(Mt);
E = cumtrapz(th*pi/180, Mt - Mm);
dE = max(E) - min(E);
delta = dE/(p.I_volante*w^2);
Ireq = dE*p.delta_obj/w^2;
R = struct('M_medio', Mm, 'M_max', max(Mt), 'M_min', min(Mt), 'dE', dE, 'delta', delta, 'I_necesaria', Ireq, ...
    'P_kW', Mm*w/1000, 'theta', th, 'M_total', Mt, 'M_gases', Mg, 'M_inercia', Mi);
sfm_tabla(sprintf('Par instantáneo · %d cilindros a %d rpm', p.z, p.n), { ...
    'Par medio indicado (N·m)', Mm, '%.1f', ''; 'Potencia indicada (kW)', R.P_kW, '%.1f', 'M·ω'; ...
    'Par máximo | mínimo (N·m)', sprintf('%.0f | %.0f', R.M_max, R.M_min), '', ''; ...
    'Fluctuación de energía ΔE (J)', dE, '%.1f', ''; 'Irregularidad δ con el volante actual', delta, '%.4f', sprintf('1/%.0f', 1/delta); ...
    'Inercia necesaria para 1/δ objetivo (kg·m²)', Ireq, '%.3f', sprintf('δ = 1/%g', p.delta_obj)});
zz = [1 2 3 4 6 8]; dz = zeros(size(zz));
for i = 1:numel(zz)
    t = zeros(size(th)); for j = 0:zz(i) - 1, t = t + circshift(M1, [0, round(j*720/zz(i)/0.5)]); end
    e = cumtrapz(th*pi/180, t - mean(t)); dz(i) = (max(e) - min(e))/(p.I_volante*w^2);
end
sfm_fig('Par instantáneo y volante', 1150, 650);
subplot(2,2,1); plot(th, Mg, 'Color', c.rojo, 'LineWidth', 1.4); hold on; plot(th, Mi, 'Color', c.azul, 'LineWidth', 1.4); plot(th, M1, 'k', 'LineWidth', 1.6)
grid on; xlim([-360 360]); set(gca, 'XTick', -360:90:360); xlabel('\theta (°)'); ylabel('N·m'); legend('gases', 'inercia', 'total'); title('Par de un cilindro')
subplot(2,2,2); plot(th + 360, Mt, 'Color', c.morado, 'LineWidth', 1.6); hold on; plot([0 720], [Mm Mm], 'k--')
grid on; xlim([0 720]); set(gca, 'XTick', 0:90:720); xlabel('\theta (°)'); ylabel('N·m'); title(sprintf('Par total del motor (%d cil.) · medio %.0f N·m', p.z, Mm))
subplot(2,2,3); plot(th + 360, 60/(2*pi)*sqrt(w^2 + 2*E/p.I_volante), 'Color', c.verde, 'LineWidth', 1.6)
grid on; xlim([0 720]); set(gca, 'XTick', 0:90:720); xlabel('\theta (°)'); ylabel('rpm'); title('Fluctuación del régimen durante el ciclo')
subplot(2,2,4); bar(1:numel(zz), 1./dz, 'FaceColor', c.naranja); set(gca, 'XTickLabel', arrayfun(@num2str, zz, 'UniformOutput', false))
grid on; xlabel('Número de cilindros'); ylabel('1/\delta (más alto = más regular)'); title('Regularidad con el mismo volante')
sfm_titulo('Par instantáneo del cigüeñal y volante de inercia');
end
