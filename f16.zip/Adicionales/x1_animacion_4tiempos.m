function x1_animacion_4tiempos(p)
%X1_ANIMACION_4TIEMPOS Animación del ciclo de cuatro tiempos: biela-manivela, válvulas y chispa.
%   x1_animacion_4tiempos()      anima dos vueltas del cigüeñal.
%   x1_animacion_4tiempos(p)     con p.S, p.L, p.D (mm), cotas AAA, RCA, AAE, RCE (°),
%                                p.avance (° antes del PMS), p.paso (°), p.pausa (s),
%                                p.animar (false = dibuja solo p.theta), p.gif (nombre de archivo o '').
%   θ = 0° es el PMS al final de la compresión (salta la chispa poco antes).
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('S', 70, 'L', 130, 'D', 76, 'AAA', 12, 'RCA', 48, 'AAE', 50, 'RCE', 10, 'avance', 15, ...
    'paso', 4, 'pausa', 0.02, 'animar', true, 'theta', 30, 'gif', ''));
c = sfm_colores();
r = p.S/2; Lb = p.L; Dp = p.D;
Hv = 0.12*Dp;                                   % alzada dibujada
dE = p.AAE + 180 + p.RCE; dA = p.AAA + 180 + p.RCA;
fases = {'EXPANSIÓN (trabajo)', 'ESCAPE', 'ADMISIÓN', 'COMPRESIÓN'};
colg = {[1 0.55 0.2], [0.6 0.6 0.6], [0.55 0.75 1], [0.7 0.85 0.7]};
fig = sfm_fig('Ciclo de cuatro tiempos', 700, 800);
if p.animar, ths = 0:p.paso:720; else, ths = p.theta; end
for th = ths
    clf; hold on; axis equal; axis off
    a = th*pi/180;                                % el cigüeñal gira en sentido horario
    cx = r*sin(a); cy = r*cos(a);                 % muñequilla
    yp = cy + sqrt(Lb^2 - cx^2);                  % bulón
    ytop = r + Lb + 0.55*Dp;                      % culata
    f = floor(mod(th, 720)/180) + 1;
    % cilindro y gas
    fill([-Dp/2 Dp/2 Dp/2 -Dp/2], [yp + 0.25*Dp, yp + 0.25*Dp, ytop, ytop], colg{f}, 'EdgeColor', 'none');
    plot([-Dp/2 -Dp/2], [r + Lb - 0.9*p.S - 0.3*Dp, ytop], 'k', 'LineWidth', 2); plot([Dp/2 Dp/2], [r + Lb - 0.9*p.S - 0.3*Dp, ytop], 'k', 'LineWidth', 2);
    plot([-Dp/2 - 0.1*Dp, Dp/2 + 0.1*Dp], [ytop ytop], 'k', 'LineWidth', 3);
    % válvulas
    hA = u3_alzada_valvula(th, 360 - p.AAA, dA, Hv); hE = u3_alzada_valvula(th, 180 - p.AAE, dE, Hv);
    local_valvula(-0.25*Dp, ytop, hA, 0.32*Dp, c.azul); local_valvula(0.25*Dp, ytop, hE, 0.32*Dp, c.rojo);
    % chispa
    if mod(th + p.avance, 720) < 25
        plot(0, ytop - 0.05*Dp, 'p', 'MarkerSize', 22, 'MarkerFaceColor', 'y', 'MarkerEdgeColor', c.naranja);
    end
    % pistón, biela, cigüeñal
    fill([-Dp/2 + 1, Dp/2 - 1, Dp/2 - 1, -Dp/2 + 1], [yp - 0.35*Dp, yp - 0.35*Dp, yp + 0.25*Dp, yp + 0.25*Dp], [0.75 0.75 0.78], 'EdgeColor', 'k');
    plot([0 cx], [yp cy], 'Color', [0.3 0.3 0.35], 'LineWidth', 6);
    t = linspace(0, 2*pi, 60); plot(1.25*r*cos(t), 1.25*r*sin(t), 'Color', [0.8 0.8 0.8]);
    plot([0 cx], [0 cy], 'k', 'LineWidth', 5); plot(0, 0, 'ko', 'MarkerFaceColor', 'k'); plot(cx, cy, 'ko', 'MarkerFaceColor', 'w'); plot(0, yp, 'ko', 'MarkerFaceColor', 'w');
    text(-Dp, ytop + 0.35*Dp, sprintf('\\theta = %3.0f°   %s', mod(th, 720), fases{f}), 'FontWeight', 'bold', 'FontSize', 12);
    if hA > 0 && hE > 0, text(-Dp, ytop + 0.2*Dp, 'CRUCE DE VÁLVULAS', 'Color', c.morado, 'FontWeight', 'bold'); end
    text(-0.25*Dp, ytop + 0.12*Dp, 'ADM', 'HorizontalAlignment', 'center', 'Color', c.azul);
    text(0.25*Dp, ytop + 0.12*Dp, 'ESC', 'HorizontalAlignment', 'center', 'Color', c.rojo);
    axis([-1.2*Dp 1.2*Dp -1.4*r ytop + 0.45*Dp]);
    drawnow;
    if ~isempty(p.gif)
        fr = getframe(fig);
        if exist('OCTAVE_VERSION', 'builtin'), [im, map] = rgb2ind(frame2im(fr)); else, [im, map] = rgb2ind(frame2im(fr), 64); end
        if th == ths(1), imwrite(im, map, p.gif, 'gif', 'LoopCount', Inf, 'DelayTime', 0.05);
        else, imwrite(im, map, p.gif, 'gif', 'WriteMode', 'append', 'DelayTime', 0.05); end
    end
    if p.animar, pause(p.pausa); end
end
end

function local_valvula(x, ytop, h, d, col)
y = ytop - h;
plot([x x], [y y + 0.9*d], 'Color', col, 'LineWidth', 3);
fill(x + [-d/2 d/2 d/6 -d/6], y + [-0.18*d -0.18*d 0 0], col, 'EdgeColor', 'k');
end
