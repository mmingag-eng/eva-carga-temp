function R = x2_combustion_wiebe(p)
%X2_COMBUSTION_WIEBE Presión en el cilindro, fracción quemada y avance óptimo (MBT).
%   R = x2_combustion_wiebe(p)
%
%   Modelo de una zona con la ley de Wiebe (ver sfm_presion_cilindro). Calcula
%   p(θ), la presión máxima y su ángulo, la pmi y la potencia indicada, y barre
%   el avance para encontrar el de máximo par (MBT).
%
%   Parámetros (estructura p), además de los de sfm_presion_cilindro:
%     z          número de cilindros                       [4]
%     barrido    avances a comparar (° antes del PMS)      [0:2:50]
%     p_lim      presión máxima admisible orientativa (bar) [70]
%   Ejemplos:  x2_combustion_wiebe(struct('avance', 35))      % avance excesivo
%              x2_combustion_wiebe(struct('p_adm', 1.0))      % a nivel del mar
if nargin < 1, p = struct(); end
z = 4; if isfield(p, 'z'), z = p.z; p = rmfield(p, 'z'); end
barr = 0:2:50; if isfield(p, 'barrido'), barr = p.barrido; p = rmfield(p, 'barrido'); end
plim = 70; if isfield(p, 'p_lim'), plim = p.p_lim; p = rmfield(p, 'p_lim'); end
c = sfm_colores();
C = sfm_presion_cilindro(p);
if ~isfield(p, 'avance'), p.avance = 20; end
if ~isfield(p, 'n'), p.n = 3000; end
pmis = zeros(size(barr)); pmx = pmis;
for k = 1:numel(barr)
    q = p; q.avance = barr(k); q.paso = 1; t = sfm_presion_cilindro(q); pmis(k) = t.pmi_bar; pmx(k) = t.pmax_bar;
end
[~, kb] = max(pmis); MBT = barr(kb);
Pi = C.W*p.n/120*z/1000;                          % kW indicados
R = struct('pmax_bar', C.pmax_bar, 'theta_pmax', C.theta_pmax, 'pmi_bar', C.pmi_bar, 'W_J', C.W, 'P_ind_kW', Pi, ...
    'MBT', MBT, 'eta_ind', C.W/C.Q, 'curva', C);
sfm_tabla('Combustión (ley de Wiebe)', { ...
    'Avance al encendido (° antes del PMS)', p.avance, '%.0f', ''; 'Energía del combustible por ciclo (J)', C.Q, '%.0f', 'mf·PCI·ηcomb'; ...
    'Presión máxima (bar)', C.pmax_bar, '%.1f', sprintf('a %.1f° después del PMS', C.theta_pmax); ...
    'Trabajo indicado por ciclo (J)', C.W, '%.0f', '∮p·dV'; 'pmi (bar)', C.pmi_bar, '%.2f', 'W/Vd'; ...
    'Rendimiento indicado (%)', R.eta_ind*100, '%.1f', 'W/Q (incluye las pérdidas de calor del modelo)'; 'Potencia indicada del motor (kW)', Pi, '%.1f', sprintf('%d cilindros a %d rpm', z, p.n); ...
    'Avance de máximo par MBT (°)', MBT, '%.0f', 'máximo de la pmi'});
if C.theta_pmax < 5, fprintf('  La presión máxima llega casi en el PMS: avance excesivo (riesgo de picado).\n');
elseif C.theta_pmax > 20, fprintf('  La presión máxima llega tarde: avance escaso, se pierde trabajo y sube la temperatura de escape.\n'); end
sfm_fig('Combustión de Wiebe', 1150, 650);
subplot(2,2,1); plot(C.theta, C.p_bar, 'Color', c.rojo, 'LineWidth', 1.8); hold on
m = p; m.eta_comb = 0; m = sfm_presion_cilindro(m);
plot(m.theta, m.p_bar, '--', 'Color', c.gris); grid on; xlim([-90 120]); xlabel('\theta (°)'); ylabel('p (bar)'); legend('con combustión', 'arrastre (sin combustión)'); title('Presión en el cilindro')
subplot(2,2,2); plot(C.theta, C.xb*100, 'Color', c.naranja, 'LineWidth', 1.8); grid on; xlim([-60 90]); xlabel('\theta (°)'); ylabel('x_b (%)'); title('Fracción de combustible quemado')
subplot(2,2,3); loglog(C.V*1e6, C.p_bar, 'Color', c.azul, 'LineWidth', 1.8); grid on; xlabel('V (cm³)'); ylabel('p (bar)'); title('Diagrama p–V (logarítmico)')
subplot(2,2,4); [ax, h1, h2] = plotyy(barr, pmis, barr, pmx); set(h1, 'LineWidth', 1.8, 'Marker', 'o'); set(h2, 'LineWidth', 1.5, 'LineStyle', '--')
ylabel(ax(1), 'pmi (bar)'); ylabel(ax(2), 'p máx (bar)'); xlabel('Avance (° antes del PMS)'); grid on; title(sprintf('Avance óptimo MBT ≈ %d°', MBT))
hold(ax(2), 'on'); plot(ax(2), barr([1 end]), [plim plim], 'r:');
sfm_titulo(sprintf('Combustión · avance %g° · %d rpm · p adm %.2f bar', p.avance, p.n, C.p_bar(1)));
end
