function R = u1_orden_encendido(p)
%U1_ORDEN_ENCENDIDO Fases de cada cilindro, válvulas y tablas para calibrar (cruce y dos vueltas).
%   R = u1_orden_encendido(p)
%
%   Parámetros (estructura p):
%     orden    orden de encendido (vector)          [1 3 4 2]   (6 cil.: [1 5 3 6 2 4])
%     theta    ángulo del cigüeñal (°); 0° = cilindro 1 en el PMS de compresión   [0]
%     AAA, RCA, AAE, RCE   cotas de distribución (°)          [12 48 50 10]
%     margen   grados alejados de las rampas para calibrar     [20]
%     animar   true: recorre 0–720° animando el diagrama        [false]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('orden', [1 3 4 2], 'theta', 0, 'AAA', 12, 'RCA', 48, 'AAE', 50, 'RCE', 10, 'margen', 20, 'animar', false));
c = sfm_colores();
z = numel(p.orden);
if ~isequal(sort(p.orden(:))', 1:z) || p.orden(1) ~= 1
    error('El orden debe empezar en 1 y contener cada cilindro una sola vez.');
end
desf = zeros(1, z);
for k = 1:z, desf(p.orden(k)) = (k - 1)*720/z; end
fase = @(th) mod(th - desf, 720);
nombres = {'Expansión', 'Escape', 'Admisión', 'Compresión'};

phi = fase(p.theta);
fprintf('\nSituación a θ = %g° (orden %s)\n', p.theta, mat2str(p.orden));
fprintf('  %-9s %-7s %-12s %-6s %-9s %-9s\n', 'Cilindro', 'φ (°)', 'Tiempo', 'Pistón', 'ADM', 'ESC');
for k = 1:z
    f = phi(k); [adm, esc] = local_valv(f, p);
    if any(abs(f - [0 360]) < 1e-9), pis = 'PMS'; elseif any(abs(f - [180 540]) < 1e-9), pis = 'PMI';
    elseif mod(f, 360) < 180, pis = 'baja'; else, pis = 'sube'; end
    extra = ''; if adm && esc, extra = '  <- CRUCE'; end
    fprintf('  %-9d %-7.0f %-12s %-6s %-9s %-9s%s\n', k, f, nombres{floor(f/180) + 1}, pis, local_ab(adm), local_ab(esc), extra);
end
% método del cruce
fprintf('\nMétodo del cruce (girar %g° de cigüeñal entre pasos):\n', 720/z);
cruce = zeros(z, 2);
for k = 1:z
    cal = p.orden(k); cr = p.orden(mod(k - 1 + z/2, z) + 1); cruce(k, :) = [cal cr];
    fprintf('  Paso %d: calibrar ADM y ESC del cilindro %d  ·  cilindro %d en cruce\n', k, cal, cr);
end
% método de dos vueltas
fprintf('\nMétodo de dos vueltas (Calibrar = leva en su círculo base):\n');
dos = cell(z, 4);
for k = 1:z
    for v = 0:1
        f = mod(360*v - desf(k), 720);
        dos{k, 2*v + 1} = local_si(f < 360 - p.AAA - p.margen || f > 540 + p.RCA + p.margen);
        dos{k, 2*v + 2} = local_si(f < 180 - p.AAE - p.margen || f > 360 + p.RCE + p.margen);
    end
    fprintf('  Cil %d · vuelta 1: ADM %-8s ESC %-8s · vuelta 2: ADM %-8s ESC %-8s\n', k, dos{k, :});
end
R = struct('desfase', desf, 'fase', phi, 'cruce', cruce, 'dos_vueltas', {dos});

% diagrama de fases
sfm_fig('Orden de encendido', 1100, 420); hold on
col = {c.rojo, c.gris, c.azul, c.verde};
for k = 1:z
    for f = 0:3
        s = mod(180*f + desf(k), 720); tramos = [s min(s + 180, 720)];
        if s + 180 > 720, tramos = [tramos; 0 s + 180 - 720]; end
        for t = 1:size(tramos, 1)
            fill([tramos(t,1) tramos(t,2) tramos(t,2) tramos(t,1)], k + [-0.35 -0.35 0.35 0.35], col{f + 1}, 'EdgeColor', 'w');
        end
    end
end
hth = plot([p.theta p.theta], [0.4 z + 0.6], 'k--', 'LineWidth', 1.5);
set(gca, 'YDir', 'reverse', 'YTick', 1:z, 'XTick', 0:90:720); xlim([0 720]); ylim([0.4 z + 0.6]); grid on
xlabel('Ángulo del cigüeñal \theta (°)'); ylabel('Cilindro')
for f = 1:4, hl(f) = fill(nan, nan, col{f}); end %#ok<AGROW>
legend(hl, nombres, 'Location', 'southoutside', 'Orientation', 'horizontal')
title(sprintf('Fases de cada cilindro · orden %s', strjoin(arrayfun(@num2str, p.orden, 'UniformOutput', false), '-')))
if p.animar
    for th = 0:5:720
        set(hth, 'XData', [th th]); drawnow; pause(0.03);
    end
end
end

function [adm, esc] = local_valv(f, p)
adm = f >= 360 - p.AAA && f <= 540 + p.RCA;
esc = f >= 180 - p.AAE && f <= 360 + p.RCE;
end
function s = local_ab(b)
if b, s = 'abierta'; else, s = 'cerrada'; end
end
function s = local_si(b)
if b, s = 'Calibrar'; else, s = '—'; end
end
