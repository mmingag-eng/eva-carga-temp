function R = u1_trucaje(p)
%U1_TRUCAJE Trucaje del motor: sobremedida, carrera, cepillado y selección de la junta.
%   R = u1_trucaje(p)
%
%   Parámetros (estructura p):
%     D            diámetro estándar (mm)                                  [86]
%     C            carrera estándar (mm)                                   [86]
%     z            número de cilindros                                     [4]
%     Rc           relación de compresión original                         [10]
%     medida       medida de reparación: 0 (STD), 10, 20 … (milésimas de pulgada) [20]
%     dC           aumento de carrera por cambio de cigüeñal (mm)          [0]
%     cepillado    material retirado de la culata (mm)                     [0.20]
%     e_junta      espesor original de la junta comprimida (mm)            [1.25]
%     sobrepaso    sobrepasamiento del pistón medido (mm)                  [0.52]
%     PME          presión media efectiva (kg/cm²)                         [10]
%     n_Pmax       régimen de potencia máxima (rpm)                        [6000]
%     Rc_objetivo  para calcular el cepillado necesario                    [10.5]
%
%   La junta se elige con la Tabla 2 de la guía (sobrepasamiento → espesor).
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('D', 86, 'C', 86, 'z', 4, 'Rc', 10, 'medida', 20, 'dC', 0, 'cepillado', 0.20, ...
    'e_junta', 1.25, 'sobrepaso', 0.52, 'PME', 10, 'n_Pmax', 6000, 'Rc_objetivo', 10.5));
c = sfm_colores();
tabla2 = [0.470 1.25; 0.505 1.30; 0.555 1.35; 0.705 1.40];   % Tabla 2 de la guía

sob = p.medida/1000*25.4;
D2 = p.D + sob; C2 = p.C + p.dC;
A1 = pi/4*(p.D/10)^2; A2 = pi/4*(D2/10)^2;
Vu1 = A1*p.C/10; Vu2 = A2*C2/10;
if p.sobrepaso < 0.47 || p.sobrepaso > 0.754
    e2 = p.e_junta; aviso_j = 'sobrepasamiento fuera de la Tabla 2: consulte el manual';
else
    e2 = tabla2(find(p.sobrepaso >= tabla2(:,1), 1, 'last'), 2); aviso_j = sprintf('junta sugerida %.2f mm (Tabla 2)', e2);
end
Vc1 = Vu1/(p.Rc - 1);
Vc2 = Vc1 - A2*p.cepillado/10 + A2*(e2 - p.e_junta)/10;
Rc2 = (Vu2 + Vc2)/Vc2;
VT1 = Vu1*p.z; VT2 = Vu2*p.z;
P1 = p.PME*VT1/1000*p.n_Pmax/900; P2 = p.PME*VT2/1000*p.n_Pmax/900;
cep_obj = (Vc2 + A2*p.cepillado/10 - Vu2/(p.Rc_objetivo - 1))/A2*10;
cep_guia = C2/(p.Rc - 1) - C2/(p.Rc_objetivo - 1);
R = struct('D', D2, 'Vu', Vu2, 'Vc', Vc2, 'Rc', Rc2, 'VT', VT2, 'P_HP', P2, 'junta', e2, ...
    'cepillado_objetivo', cep_obj, 'cepillado_formula_guia', cep_guia);

sfm_tabla('Trucaje del motor (original | modificado)', { ...
    'Sobremedida del cilindro (mm)', sob, '%.3f', sprintf('medida %d = 0,%03d pulg', p.medida, p.medida); ...
    'Diámetro (mm)', sprintf('%.3f | %.3f', p.D, D2), '', ''; ...
    'Carrera (mm)', sprintf('%.2f | %.2f', p.C, C2), '', ''; ...
    'Cilindrada unitaria (cm³)', sprintf('%.2f | %.2f', Vu1, Vu2), '', 'Vu = π·D²/4·C'; ...
    'Espesor de la junta (mm)', sprintf('%.2f | %.2f', p.e_junta, e2), '', aviso_j; ...
    'Volumen de la cámara Vc (cm³)', sprintf('%.2f | %.2f', Vc1, Vc2), '', 'cepillado −A·x, junta +A·Δe'; ...
    'Relación de compresión', sprintf('%.2f | %.2f', p.Rc, Rc2), '', ''; ...
    'Cilindrada total (cm³)', sprintf('%.1f | %.1f', VT1, VT2), '', sprintf('+%.2f %%', (VT2/VT1 - 1)*100); ...
    'Potencia estimada (HP)', sprintf('%.1f | %.1f', P1, P2), '', 'P = PME·VT·n/900'; ...
    'Cepillado para Rc objetivo (mm)', cep_obj, '%.3f', 'con diámetro y junta modificados'; ...
    'Cepillado con x = C/(Ea−1) − C/(En−1) (mm)', cep_guia, '%.3f', 'fórmula de la guía'});
if Rc2 > 11.5, fprintf('  ATENCIÓN: Rc muy alta, riesgo de detonación.\n');
elseif Rc2 > 11, fprintf('  Rc alta: usar gasolina súper y revisar el avance.\n'); end
if sob > 1.02, fprintf('  Sobremedida > 0,040 pulg: verificar el espesor de pared o encamisar.\n'); end

x = 0:0.05:1.2;
Vcx = Vc2 + A2*p.cepillado/10 - A2*x/10;
sfm_fig('Trucaje del motor', 1100, 480);
subplot(1,2,1)
plot(x, (Vu2 + Vcx)./Vcx, 'Color', c.azul, 'LineWidth', 1.8); hold on
plot(p.cepillado, Rc2, 'o', 'Color', c.naranja, 'MarkerFaceColor', c.naranja, 'MarkerSize', 8)
grid on; xlabel('Cepillado de la culata (mm)'); ylabel('Rc'); title('Rc según el cepillado (motor modificado)')
sfm_linea('y', 11, 'r--', 'precaución Rc 11'); legend('Rc', 'actual', 'Location', 'northwest')
subplot(1,2,2)
b = bar([VT1 VT2; P1*10 P2*10; p.Rc*100 Rc2*100]'); grid on
set(gca, 'XTickLabel', {'Original', 'Modificado'});
legend('VT (cm³)', 'Potencia ×10 (HP)', 'Rc ×100', 'Location', 'southoutside'); title('Comparación (escalas indicadas)')
sfm_titulo('Trucaje del motor');
end
