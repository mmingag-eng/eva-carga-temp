function R = u1_orden_encendido_motores(p)
%U1_ORDEN_ENCENDIDO_MOTORES Orden de encendido según el número y la disposición de los cilindros.
%   R = u1_orden_encendido_motores(p)
%
%   Reproduce el libro SFM_Simulador_Orden_Encendido.xlsx: 24 configuraciones (1 a 12 cilindros,
%   en línea, en V, VR, bóxer y radiales) o un orden personalizado en línea. Dibuja la vista de
%   frente de las muñequillas, la disposición de los muñones (cigüeñal visto de lado), el esquema
%   de los cilindros, el diagrama de fases, los cilindros en expansión y el cigüeñal en 3D.
%
%   Parámetros (estructura p):
%     config     número de la configuración (1–24) o parte de su nombre, p. ej. 'V8 plano' o 'bóxer'  [8]
%     orden      orden personalizado para un motor en línea, p. ej. [1 5 3 6 2 4]; [] usa config  []
%     theta      ángulo del cigüeñal θ (°, 0 = cilindro 1 en PMS al final de la compresión)       [0]
%     listar     true imprime la lista de configuraciones y termine                                [false]
%     vista3d    true dibuja también el cigüeñal en 3D                                             [true]
%     animar     true gira el cigüeñal de 0 a 720° (los dos gráficos se actualizan)                 [false]
%     paso, pausa  paso (°) y pausa (s) de la animación                                          [6 0.03]
%     gif        nombre de archivo para guardar la animación del cigüeñal 3D ('' = no)            ['']
%
%   Ejemplos:
%     u1_orden_encendido_motores(struct('listar', true))
%     u1_orden_encendido_motores(struct('config', 'cruciforme', 'theta', 90))
%     u1_orden_encendido_motores(struct('orden', [1 2 4 3]))
%     u1_orden_encendido_motores(struct('config', 'VR6', 'animar', true))
%
%   Convenios: β es el eje de cada cilindro y ψ el ángulo de su muñequilla, ambos en grados,
%   en sentido horario desde la vertical y con el cilindro 1 en PMS (θ = 0). El cilindro i
%   enciende en θ = a_i, de modo que ψ_i = MOD(β_i − a_i, 360). Fase: φ = MOD(θ − a_i, 720).
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('config', 8, 'orden', [], 'theta', 0, 'listar', false, 'vista3d', true, ...
    'animar', false, 'paso', 6, 'pausa', 0.03, 'gif', ''));
C = sfm_catalogo_motores();
if p.listar
    fprintf('\nConfiguraciones disponibles (use su número o parte del nombre en p.config)\n');
    for k = 1:numel(C), fprintf('  %2d  %s\n', k, C(k).nombre); end
    R = C; return
end
m = local_motor(p, C);
z = m.z; a = m.a(:)'; psi = mod(m.beta - a, 360);
% ---------- intervalos entre encendidos
as = sort(a); iv = diff([as as(1) + 720]);
if all(abs(iv - iv(1)) < 1e-6), reg = 'regulares'; else, reg = 'irregulares'; end
ivs = strjoin(arrayfun(@(v) local_g(v), iv, 'UniformOutput', false), ', ');
% ---------- estado en θ
[fase, nfase, pos] = local_fases(p.theta, a);
nexp = sum(nfase == 1);
ie = find(nfase == 1); enc = '—';
if ~isempty(ie), [~, j] = min(fase(ie)); enc = sprintf('%d', ie(j)); end
sfm_tabla(sprintf('Orden de encendido · %s', m.nombre), { ...
    'Número de cilindros z', z, '%d', ''; 'Orden de encendido', strjoin(arrayfun(@(v) sprintf('%d', v), m.orden, 'UniformOutput', false), '-'), '', ''; ...
    'Disposición', local_disp(m), '', ''; 'División del ciclo (°)', 720/z, '%.4g', '720° / z'; ...
    'Intervalos entre encendidos (°)', ivs, '', reg; ...
    sprintf('Cilindros en expansión en θ = %g°', mod(p.theta, 720)), nexp, '%d', ''; ...
    'Cilindro que acaba de encender', enc, '', ''});
fprintf('  %s\n', m.desc);
nombres = {'Expansión', 'Escape', 'Admisión', 'Compresión'};
fprintf('\n  Cil.  Banc.   β (°)   a (°)   ψ (°)   φ (°)   Tiempo       Pistón\n');
for i = 1:z
    fprintf('  %-5d %-6s %6.4g  %6.4g  %6.4g  %6.4g   %-12s %s\n', i, m.banco(i), m.beta(i), a(i), psi(i), fase(i), nombres{nfase(i)}, pos{i});
end
% muñequillas compartidas
[u, ~, g] = unique(round(psi*100)/100);
if numel(u) < z && ~strcmp(m.tipo, 'Radial')
    fprintf('  Posiciones angulares distintas de las muñequillas: %d (ver la vista de frente).\n', numel(u));
end
R = struct('motor', m, 'a', a, 'psi', psi, 'intervalos', iv, 'division', 720/z, 'fase', fase, ...
    'tiempo', {nombres(nfase)}, 'n_expansion', nexp, 'grupo_munequilla', g(:)');
% ---------- gráficos
if p.animar, ths = 0:p.paso:720; else, ths = p.theta; end
f1 = sfm_fig(['Orden de encendido · ' m.nombre], 1250, 720);
if p.vista3d, f2 = sfm_fig('Cigüeñal en 3D', 760, 560); end
for th = ths
    figure(f1); clf; local_figura(m, a, psi, th);
    if p.vista3d
        figure(f2); clf; local_ciguenal3d(m, a, psi, th);
        if ~isempty(p.gif)
            fr = getframe(f2);
            if exist('OCTAVE_VERSION', 'builtin'), [im, map] = rgb2ind(frame2im(fr)); else, [im, map] = rgb2ind(frame2im(fr), 64); end
            if th == ths(1), imwrite(im, map, p.gif, 'gif', 'LoopCount', Inf, 'DelayTime', 0.05);
            else, imwrite(im, map, p.gif, 'gif', 'WriteMode', 'append', 'DelayTime', 0.05); end
        end
    end
    drawnow; if p.animar, pause(p.pausa); end
end
if p.vista3d, figure(f1); end
end

% =====================================================================================
function m = local_motor(p, C)
if ~isempty(p.orden)
    o = p.orden(:)'; z = numel(o);
    if z < 1 || z > 12, error('El orden personalizado debe tener de 1 a 12 cilindros.'); end
    if ~isequal(sort(o), 1:z), error('Revise el orden: cada cilindro de 1 a %d debe aparecer una sola vez.', z); end
    if o(1) ~= 1, error('El orden debe empezar por el cilindro 1.'); end
    a = zeros(1, z); a(o) = (0:z-1)*720/z;
    m = struct('nombre', sprintf('%d cilindros en línea (orden personalizado)', z), 'tipo', 'En línea', 'vang', 0, ...
        'z', z, 'orden', o, 'beta', zeros(1, z), 'x', 1:z, 'y', zeros(1, z), 'banco', repmat('-', 1, z), 'a', a, ...
        'desc', 'Orden personalizado con encendidos regulares; compruebe en la vista lateral cómo debe ser el cigüeñal.');
    return
end
k = p.config;
if ischar(k)
    hit = find(cellfun(@(s) ~isempty(strfind(lower(s), lower(k))), {C.nombre}));
    if isempty(hit) && ~isempty(strfind(lower(k), 'plano')), hit = find(cellfun(@(s) ~isempty(strfind(s, 'plano')), {C.nombre})); end
    if isempty(hit), error('No hay ninguna configuración que contenga "%s". Use struct(''listar'', true).', k); end
    k = hit(1);
end
if k < 1 || k > numel(C), error('La configuración debe estar entre 1 y %d.', numel(C)); end
m = C(k);
end

function [fase, nf, pos] = local_fases(th, a)
fase = mod(th - a, 720); nf = floor(fase/180) + 1; nf(nf > 4) = 4;
pos = cell(size(a));
for i = 1:numel(a)
    q = mod(fase(i), 360);
    if q < 1e-6 || abs(q - 360) < 1e-6, pos{i} = 'PMS';
    elseif abs(q - 180) < 1e-6, pos{i} = 'PMI';
    elseif q < 180, pos{i} = 'baja';
    else, pos{i} = 'sube'; end
end
end

function s = local_disp(m)
switch m.tipo
    case 'En línea', s = 'En línea';
    case 'Radial', s = sprintf('Radial (cilindros a %.4g°)', m.vang);
    case 'Bóxer', s = 'Horizontales opuestos (bóxer, 180°)';
    otherwise, s = sprintf('%s a %g°', m.tipo, m.vang);
end
end

function s = local_g(v)
if abs(v - round(v)) < 1e-6, s = sprintf('%d°', round(v)); else, s = sprintf('%.1f°', v); end
end

function col = local_col(i)
P = [0.84 0.19 0.12; 0.12 0.31 0.85; 0.18 0.62 0.27; 0.91 0.31 0.12; 0.48 0.18 0.66; 0.72 0.53 0.04; ...
     0.09 0.75 0.81; 0.55 0.34 0.29; 0.89 0.47 0.76; 0.33 0.33 0.33; 0.74 0.74 0.13; 0.12 0.23 0.37];
col = P(mod(i - 1, 12) + 1, :);
end

function c = local_cfase(n)
F = [0.95 0.45 0.15; 0.62 0.62 0.62; 0.55 0.75 1.00; 0.62 0.84 0.60];
c = F(n, :);
end

function xa = local_axial(m)
if strcmp(m.tipo, 'Radial'), xa = ones(1, m.z); else, xa = m.x; end
end

% =====================================================================================
function local_figura(m, a, psi, th)
z = m.z; [fase, nf] = local_fases(th, a);
% ---- 1. vista de frente
subplot(2, 3, 1); hold on; axis equal; axis off
t = linspace(0, 2*pi, 120); plot(cos(t), sin(t), 'Color', [0.7 0.7 0.7]);
for b = unique(round(m.beta*100)/100)
    plot([0 1.45*sind(b)], [0 1.45*cosd(b)], '--', 'Color', [0.6 0.6 0.6]);
end
[~, ~, g] = unique(round(psi*100)/100);
for k = unique(g(:))'
    ii = find(g == k); al = psi(ii(1)) + th;
    xp = sind(al); yp = cosd(al);
    plot([0 xp], [0 yp], 'Color', [0.3 0.3 0.35], 'LineWidth', 4);
    plot(xp, yp, 'o', 'MarkerSize', 13, 'MarkerFaceColor', local_col(ii(1)), 'MarkerEdgeColor', 'k');
    lab = strjoin(arrayfun(@(v) sprintf('%d', v), ii(:)', 'UniformOutput', false), ',');
    text(1.27*xp, 1.27*yp, lab, 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
end
plot(0, 0, 'ko', 'MarkerFaceColor', 'k');
text(0, 1.62, 'PMS cil. 1', 'HorizontalAlignment', 'center', 'FontSize', 8, 'Color', [0.4 0.4 0.4]);
axis([-1.7 1.7 -1.5 1.75]);
title(sprintf('Muñequillas vistas de frente (θ = %g°)', mod(th, 720)));
% ---- 2. vista lateral (disposición de los muñones)
subplot(2, 3, 2); hold on
xa = local_axial(m); d = psi - psi(1);
h = (cosd(d) + 0.4*sind(d))/1.077;
grp = local_grupos(xa, psi);
plot([min(xa) - 0.6, max(xa) + 0.6], [0 0], 'k', 'LineWidth', 2.5);
for q = 1:numel(grp)
    gi = sort(grp{q}); i = gi(1); hq = h(i);
    xs = [min(xa(gi)) - 0.15, max(xa(gi)) + 0.15];
    plot(xs([1 1 2 2]), [0 hq hq 0], 'Color', local_col(i), 'LineWidth', 2.5);
    lab = sprintf('%s (%.0f°)', strjoin(arrayfun(@(v) sprintf('%d', v), gi, 'UniformOutput', false), ','), psi(i));
    sg = sign(hq + (hq == 0)); dy = 0.13 + 0.17*mod(q + 1, 2)*(numel(grp) > 4);
    text(mean(xs), hq + sg*dy, lab, 'HorizontalAlignment', 'center', 'FontSize', 8, 'Color', local_col(i)*0.8);
end
ylim([-1.45 1.45]); xlim([min(xa) - 0.7, max(xa) + 0.7]); grid on
xlabel('Posición a lo largo del cigüeñal'); ylabel('Altura relativa de la muñequilla');
title('Disposición de los muñones (vista lateral)');
% ---- 3. esquema
subplot(2, 3, 3); hold on; axis equal; axis off
if strcmp(m.tipo, 'Radial')
    for i = 1:z, plot([0 m.x(i)], [0 m.y(i)], 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5); end
    plot(0, 0, 'ko', 'MarkerSize', 10, 'MarkerFaceColor', [0.4 0.4 0.4]); rr = 0.2;
else
    plot([min(m.x) - 0.5, max(m.x) + 0.5], [0 0], 'k', 'LineWidth', 2); rr = 0.17 + 0.05*(max(abs(m.y)) >= 1);
end
for i = 1:z
    t = linspace(0, 2*pi, 40);
    fill(m.x(i) + rr*cos(t), m.y(i) + rr*sin(t), local_cfase(nf(i)), 'EdgeColor', local_col(i), 'LineWidth', 2);
    text(m.x(i), m.y(i), sprintf('%d', i), 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
end
if any(m.banco == 'A')
    ya = m.y(find(m.banco == 'A', 1)); yb = m.y(find(m.banco == 'B', 1));
    text(min(m.x) - 0.45, ya, 'A', 'FontWeight', 'bold', 'HorizontalAlignment', 'right'); text(min(m.x) - 0.45, yb, 'B', 'FontWeight', 'bold', 'HorizontalAlignment', 'right');
end
nombres = {'Expansión', 'Escape', 'Admisión', 'Compresión'};
title({sprintf('Disposición de los cilindros (%s)', local_disp(m)), 'relleno = tiempo en θ (colores del diagrama de fases)'});
axis tight; ax = axis; axis(ax + [-0.45 0.3 -0.3 0.3]);
% ---- 4. diagrama de fases
subplot(2, 3, [4 5]); hold on
for i = 1:z
    for k = 0:3
        s0 = mod(a(i) + 180*k, 720); s1 = s0 + 180;
        segs = [s0 min(s1, 720)]; if s1 > 720, segs = [segs; 0 s1 - 720]; end
        for q = 1:size(segs, 1)
            fill(segs(q, [1 2 2 1]), i + [-0.4 -0.4 0.4 0.4], local_cfase(k + 1), 'EdgeColor', 'w');
            if diff(segs(q, :)) > 40
                text(mean(segs(q, :)), i, nombres{k + 1}(1:min(4, end)), 'HorizontalAlignment', 'center', 'FontSize', 7);
            end
        end
    end
    plot(mod(a(i), 720), i - 0.45, 'p', 'MarkerSize', 10, 'MarkerFaceColor', 'y', 'MarkerEdgeColor', [0.8 0.4 0]);
end
plot(mod(th, 720)*[1 1], [0.4 z + 0.6], 'k-', 'LineWidth', 2);
set(gca, 'YDir', 'reverse', 'YTick', 1:z, 'XTick', 0:90:720); xlim([0 720]); ylim([0.4 z + 0.6]);
xlabel('Ángulo del cigüeñal θ (°)'); ylabel('Cilindro'); grid on
title(sprintf('Diagrama de fases · orden %s · estrella = chispa', strjoin(arrayfun(@(v) sprintf('%d', v), m.orden, 'UniformOutput', false), '-')));
% ---- 5. cilindros en expansión
subplot(2, 3, 6); hold on
tt = 0:1:720; n = zeros(size(tt));
for k = 1:numel(tt), n(k) = sum(mod(tt(k) - a, 720) < 180); end
stairs(tt, n, 'Color', [0.91 0.31 0.12], 'LineWidth', 2);
plot(mod(th, 720)*[1 1], [0 max(n) + 1], 'k--');
xlim([0 720]); ylim([0 max(n) + 1]); set(gca, 'XTick', 0:180:720); grid on
xlabel('θ (°)'); ylabel('Cilindros');
title('Cilindros en expansión');
sfm_titulo(sprintf('%s · división 720°/%d = %s · θ = %g°', m.nombre, z, local_g(720/z), mod(th, 720)));
end

% =====================================================================================
function local_ciguenal3d(m, a, psi, th)
hold on; axis equal; axis off
xa = local_axial(m); r = 0.55; z = m.z;
grp = local_grupos(xa, psi);
gris = [0.72 0.72 0.75]; x0 = min(xa) - 0.75; x1 = max(xa) + 0.75;
spans = zeros(numel(grp), 2);
for q = 1:numel(grp), spans(q, :) = [min(xa(grp{q})) - 0.17, max(xa(grp{q})) + 0.17]; end
% muñones de bancada (entre codos)
bord = [x0, reshape(spans', 1, []), x1];
for q = 1:2:numel(bord) - 1
    if bord(q + 1) - bord(q) > 0.05, local_cil(bord(q), bord(q + 1) - 0.06, 0, 0, 0.26, gris); end
end
% codos: brazos y muñequillas
for q = 1:numel(grp)
    i = grp{q}(1); al = psi(i) + th;
    yc = -r*sind(al); zc = r*cosd(al);
    for xw = [spans(q, 1) - 0.06, spans(q, 2)]
        local_brazo(xw, xw + 0.06, yc, zc, al);
    end
    local_cil(spans(q, 1), spans(q, 2), yc, zc, 0.2, local_col(i));
    lab = strjoin(arrayfun(@(v) sprintf('%d', v), sort(grp{q}), 'UniformOutput', false), ',');
    text(mean(spans(q, :)), 1.35*yc, 1.35*zc + 0.35, lab, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
end
% polea delantera y volante
local_cil(x0 - 0.25, x0, 0, 0, 0.45, [0.35 0.35 0.38]);
local_cil(x1, x1 + 0.18, 0, 0, 1.25, [0.45 0.45 0.5]);
xv = x1 + 0.19; t = th*pi/180;
plot3([xv xv], [0 -1.15*sin(t)], [0 1.15*cos(t)], 'w', 'LineWidth', 3);   % marca de giro del volante
view(-32, 28); try, camlight headlight; lighting gouraud; catch, end
title(sprintf('Cigüeñal · %s · θ = %g° (gira con θ)', m.nombre, mod(th, 720)));
axis([x0 - 0.4, x1 + 0.4, -1.4, 1.4, -1.4, 1.5]);
end

function grp = local_grupos(xa, psi)
% cilindros que comparten muñequilla: posición axial cercana (< 0,5) y el mismo ψ
z = numel(xa); [xs, ord] = sort(xa); grp = {}; k = 1;
while k <= z
    gi = ord(k); j = k + 1;
    while j <= z && xs(j) - xs(j - 1) < 0.5 && abs(mod(psi(ord(j)) - psi(gi(1)) + 180, 360) - 180) < 0.5
        gi(end + 1) = ord(j); j = j + 1; %#ok<AGROW>
    end
    grp{end + 1} = gi; k = j; %#ok<AGROW>
end
end

function local_cil(xa, xb, yc, zc, R, col)
t = linspace(0, 2*pi, 28);
X = [xa*ones(1, 28); xb*ones(1, 28)]; Y = yc + R*[cos(t); cos(t)]; Z = zc + R*[sin(t); sin(t)];
surf(X, Y, Z, 'FaceColor', col, 'EdgeColor', 'none');
fill3(xa*ones(1, 28), yc + R*cos(t), zc + R*sin(t), col, 'EdgeColor', 'none');
fill3(xb*ones(1, 28), yc + R*cos(t), zc + R*sin(t), col, 'EdgeColor', 'none');
end

function local_brazo(xa, xb, yc, zc, al)
% brazo del cigüeñal: rodea la muñequilla y lleva el contrapeso en el lado opuesto
r = sqrt(yc^2 + zc^2); w = 0.28; Rc = 0.85;
u = [-sind(al) cosd(al)]; v = [cosd(al) sind(al)];     % u hacia la muñequilla, v perpendicular
f1 = linspace(90, -90, 15)'; f2 = linspace(235, 125, 15)';
pts = [r*u + w*(cosd(f1)*u + sind(f1)*v); Rc*(cosd(f2)*u + sind(f2)*v)];
Y = pts(:, 1)'; Z = pts(:, 2)'; n = numel(Y); col = [0.6 0.6 0.64];
fill3(xa*ones(1, n), Y, Z, col, 'EdgeColor', [0.4 0.4 0.4]);
fill3(xb*ones(1, n), Y, Z, col, 'EdgeColor', [0.4 0.4 0.4]);
for k = 1:n
    k2 = mod(k, n) + 1;
    fill3([xa xb xb xa], [Y(k) Y(k) Y(k2) Y(k2)], [Z(k) Z(k) Z(k2) Z(k2)], col, 'EdgeColor', 'none');
end
end
