function R = u1_reloj_comparador(p)
%U1_RELOJ_COMPARADOR Lectura del reloj comparador (0,01 mm o 0,001").
%   R = u1_reloj_comparador(p)
%
%   Parámetros (estructura p):
%     sistema           'mm' (1 mm por vuelta) o 'pulg' (0,1" por vuelta) ['mm']
%     lectura           desplazamiento del palpador; [] = aleatorio        []
%     ejercicio         semilla                                            [1]
%     respuesta         su lectura                                         []
%     mostrar_solucion  true/false                                         [true]
%
%   L = vueltas del cuentavueltas × (1 mm o 0,1") + divisiones × apreciación
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('sistema', 'mm', 'lectura', [], 'ejercicio', 1, 'respuesta', [], 'mostrar_solucion', true));
c = sfm_colores();
if strcmpi(p.sistema, 'mm'), res = 0.01; vuelta = 1; u = 'mm'; maxv = 9.99;
else, res = 0.001; vuelta = 0.1; u = 'pulg'; maxv = 0.999; end
if isempty(p.lectura)
    rng(3000 + p.ejercicio);
    L = res*round(rand*maxv/res);
else
    L = res*round(p.lectura/res);
end
nv = floor(L/vuelta + 1e-9); dv = round((L - nv*vuelta)/res);
R = struct('lectura', L, 'vueltas', nv, 'divisiones', dv, 'unidad', u);

sfm_fig('Reloj comparador', 650, 700); hold on; axis equal; axis off
local_dial([0 0], 1, 100, 10, dv/100, c, p.mostrar_solucion);
local_dial([0 -0.42], 0.22, 10, 5, (L/vuelta)/10, c, false);
text(0, -1.1, sprintf('apreciación %g %s · 1 vuelta = %g %s', res, u, vuelta, u), 'HorizontalAlignment', 'center', 'FontSize', 9);
title(sprintf('Reloj comparador (%s) · ejercicio %d', u, p.ejercicio));
sol = sprintf('Cuentavueltas: %d × %g + aguja grande: %d × %g  ->  L = %g %s', nv, vuelta, dv, res, L, u);
if ~isempty(p.respuesta)
    ok = abs(p.respuesta - L) < res/2; R.correcta = ok;
    if ok, fprintf('\nSu respuesta %.4g es CORRECTA.\n', p.respuesta); else, fprintf('\nSu respuesta %.4g es incorrecta.\n', p.respuesta); end
end
if p.mostrar_solucion
    fprintf('\nSOLUCIÓN: %s\n', sol); text(0, -1.25, sol, 'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'Color', c.rojo);
end
axis([-1.3 1.3 -1.35 1.25]);
end

function local_dial(c0, r, ndiv, nlab, frac, c, resaltar)
t = linspace(0, 2*pi, 200);
fill(c0(1) + r*cos(t), c0(2) + r*sin(t), [0.98 0.98 0.96], 'EdgeColor', [0.3 0.3 0.3], 'LineWidth', 1.5);
for k = 0:ndiv-1
    a = pi/2 - 2*pi*k/ndiv; l = 0.06*r; if mod(k, 5) == 0, l = 0.1*r; end
    if mod(k, nlab) == 0, l = 0.14*r;
        text(c0(1) + 0.75*r*cos(a), c0(2) + 0.75*r*sin(a), sprintf('%d', k), 'HorizontalAlignment', 'center', 'FontSize', 8 + 2*(r > 0.5));
    end
    plot(c0(1) + [r - l, r]*cos(a), c0(2) + [r - l, r]*sin(a), 'k');
end
a = pi/2 - 2*pi*frac; col = 'k'; if resaltar, col = c.rojo; end
plot(c0(1) + [0 0.9*r*cos(a)], c0(2) + [0 0.9*r*sin(a)], 'Color', col, 'LineWidth', 2.2);
plot(c0(1), c0(2), 'ko', 'MarkerFaceColor', 'k', 'MarkerSize', 5);
end
