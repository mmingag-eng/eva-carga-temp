function R = u1_curvas_par_potencia(p)
%U1_CURVAS_PAR_POTENCIA Curvas de par, potencia y consumo; corrección por altitud (DIN 70020).
%   R = u1_curvas_par_potencia(p)
%
%   Parámetros (estructura p):
%     n         régimen (rpm), vector                  [1000:500:6500]
%     M         par a plena carga (N·m), vector        [ejemplo de motor 1,6 L]
%     ce        consumo específico (g/kWh), vector     [ejemplo]
%     altitud   altitud del lugar (m)                  [2100]  (Loja)
%     T         temperatura del aire (°C)              [18]
%
%   P (kW) = M·n/9550 · factor DIN = (p/101,3)·√(293/T).
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('n', 1000:500:6500, ...
    'M', [105 118 128 136 142 146 148 146 141 133 122 108], ...
    'ce', [330 300 280 265 255 250 248 252 260 272 290 315], 'altitud', 2100, 'T', 18));
c = sfm_colores();

P = p.M.*p.n/9550;                            % kW
patm = 101.325*(1 - 2.25577e-5*p.altitud)^5.25588;   % kPa
f = (patm/101.3)*sqrt(293/(p.T + 273));
Pl = P*f;
[Mmax, iM] = max(p.M); [Pmax, iP] = max(P);
R = struct('P_kW', P, 'P_lugar', Pl, 'factor', f, 'M_max', Mmax, 'n_Mmax', p.n(iM), ...
           'P_max', Pmax, 'n_Pmax', p.n(iP), 'elasticidad', p.n(iP)/p.n(iM));

sfm_tabla('Curvas características', { ...
    'Par máximo (N·m)', sprintf('%.0f a %d rpm', Mmax, p.n(iM)), '', ''; ...
    'Potencia máxima (kW)', sprintf('%.1f a %d rpm (%.0f CV)', Pmax, p.n(iP), Pmax/0.7355), '', 'P = M·n/9550'; ...
    'Presión atmosférica en el lugar (kPa)', patm, '%.1f', 'atmósfera estándar'; ...
    'Factor de corrección DIN 70020', f, '%.3f', '(p/101,3)·√(293/T)'; ...
    'Potencia máxima en el lugar (kW)', max(Pl), '%.1f', ''; ...
    'Pérdida de potencia por altitud (%)', (1-f)*100, '%.1f', ''; ...
    'Elasticidad n(Pmáx)/n(Mmáx)', R.elasticidad, '%.2f', ''; ...
    'Consumo específico mínimo (g/kWh)', min(p.ce), '%.0f', ''});

sfm_fig('Curvas par-potencia');
subplot(1,2,1)
[ax, h1, h2] = plotyy(p.n, p.M, p.n, [P(:) Pl(:)]);
set(h1, 'Color', c.azul, 'LineWidth', 1.8, 'Marker', 'o');
set(h2(1), 'Color', c.naranja, 'LineWidth', 1.8, 'Marker', 'o'); set(h2(2), 'Color', c.naranja, 'LineStyle', '--', 'LineWidth', 1.5);
ylabel(ax(1), 'Par (N·m)'); ylabel(ax(2), 'Potencia (kW)'); xlabel('Régimen (rpm)'); grid on
title('Par y potencia a plena carga'); legend([h1; h2], 'Par', 'Potencia (nivel del mar)', 'Potencia en la altitud', 'Location', 'south')
subplot(1,2,2)
plot(p.n, p.ce, '-o', 'Color', c.verde, 'LineWidth', 1.8); grid on
xlabel('Régimen (rpm)'); ylabel('c_e (g/kWh)'); title('Consumo específico')
sfm_titulo('Curvas características del motor');
end
