function R = u1_micrometro(p)
%U1_MICROMETRO Simulador de lectura del micrómetro de exteriores (mm y pulgadas).
%   R = u1_micrometro(p)
%
%   Parámetros (estructura p):
%     sistema           'mm' (0,01 mm) o 'pulg' (0,001")             ['mm']
%     rango             inicio del rango del micrómetro (0, 25, 50…)  [0]
%     lectura           valor a representar; [] = aleatoria          []
%     ejercicio         semilla del ejercicio aleatorio               [1]
%     respuesta         su lectura para autocorregir                  []
%     mostrar_solucion  true/false                                    [true]
%
%   mm:   L = rango + escala del cilindro (mm y medios mm) + división del tambor × 0,01
%   pulg: L = rango + números × 0,100 + líneas × 0,025 + división del tambor × 0,001
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('sistema', 'mm', 'rango', 0, 'lectura', [], 'ejercicio', 1, ...
    'respuesta', [], 'mostrar_solucion', true));
c = sfm_colores();
mm = strcmpi(p.sistema, 'mm');
if mm, paso = 0.5; div = 50; res = 0.01; long = 25; u = 'mm';
else,  paso = 0.025; div = 25; res = 0.001; long = 1; u = 'pulg'; end
if isempty(p.lectura)
    rng(2000 + p.ejercicio);
    L = p.rango + res*round(rand*(long - res)/res);
else
    L = res*round(p.lectura/res);
end
x = L - p.rango;                          % lectura dentro del rango
cil = paso*floor(x/paso + 1e-9);          % última línea visible del cilindro
t = round((x - cil)/res);                 % división del tambor
R = struct('lectura', L, 'cilindro', p.rango + cil, 'tambor', t, 'unidad', u);

sfm_fig('Micrómetro', 1100, 450); hold on; axis off
sc = 25/long;                              % escala de dibujo: el rango ocupa 25 unidades
X = @(v) v*sc;
x0 = -2; xt = X(cil) + 0.4*X(paso);        % borde del tambor, pasada la última línea visible
plot([x0 xt], [0 0], 'k', 'LineWidth', 1.5);
if mm
    for i = 0:floor(cil + 1e-9)
        plot(X([i i]), [0 0.5], 'k'); if mod(i, 5) == 0, text(X(i), 0.75, sprintf('%d', i + p.rango), 'HorizontalAlignment', 'center'); end
    end
    for i = 0:floor(cil - 0.5 + 1e-9)
        plot(X([i+0.5 i+0.5]), [0 -0.35], 'k');
    end
else
    for i = 0:round(cil/0.025)
        xx = X(i*0.025); h = 0.35; if mod(i, 4) == 0, h = 0.55; text(xx, 0.75, sprintf('%d', i/4), 'HorizontalAlignment', 'center'); end
        plot([xx xx], [0 h], 'k');
    end
end
W = 9; H = 2.4; s = 0.16;
fill([xt xt+W xt+W xt], [-H/2 -H/2 H/2 H/2], [0.9 0.9 0.92], 'EdgeColor', [0.4 0.4 0.4]);
for kk = -7:7
    dv = mod(t + kk, div); y = kk*s;
    hlen = 1; if mod(dv, 5) == 0, hlen = 1.7; text(xt + hlen + 0.25, y, sprintf('%d', dv), 'FontSize', 8); end
    col = 'k'; lw = 1; if kk == 0 && p.mostrar_solucion, col = c.rojo; lw = 2.2; end
    plot([xt xt + hlen], [y y], 'Color', col, 'LineWidth', lw);
end
axis([x0 xt + W + 1 -1.7 1.4]);
title(sprintf('Micrómetro %s · apreciación %g %s · rango %g–%g %s · ejercicio %d', u, res, u, p.rango, p.rango + long, u, p.ejercicio));

if mm
    sol = sprintf('Cilindro: %.2f mm  +  tambor: %d × 0,01 = %.2f mm  ->  L = %.2f mm', p.rango + cil, t, t*res, L);
else
    num = floor(cil/0.1 + 1e-9); lin = round((cil - num*0.1)/0.025);
    sol = sprintf('%d × 0,100 + %d × 0,025 + %d × 0,001 (+ rango %g)  ->  L = %.3f pulg', num, lin, t, p.rango, L);
end
if ~isempty(p.respuesta)
    ok = abs(p.respuesta - L) < res/2; R.correcta = ok;
    if ok, fprintf('\nSu respuesta %.4g es CORRECTA.\n', p.respuesta); else, fprintf('\nSu respuesta %.4g es incorrecta.\n', p.respuesta); end
end
if p.mostrar_solucion
    fprintf('\nSOLUCIÓN: %s\n', sol);
    text(x0, -1.45, sol, 'FontWeight', 'bold', 'Color', c.rojo);
end
end
