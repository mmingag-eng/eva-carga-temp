function R = u1_ciclo_otto(p)
%U1_CICLO_OTTO Ciclo Otto teórico frente al ciclo real aproximado (diagrama p–V).
%   R = u1_ciclo_otto(p)
%
%   Parámetros (estructura p):
%     Vu      cilindrada unitaria (cm³)                      [499.6]
%     Rc      relación de compresión                         [10]
%     p1      presión atmosférica (kg/cm²)  (Loja ≈ 0,80)    [1.033]
%     gamma   coeficiente adiabático (ciclo teórico)         [1.4]
%     n_pol   exponente politrópico (ciclo real)             [1.3]
%     alfa    relación de explosión p3/p2 (guía: 4)          [4]
%     perdida pérdida de compresión real (%)                 [15]
%
%   Teórico: p2 = p1·Rc^γ, p3 = α·p2, η = 1 − 1/Rc^(γ−1).
%   Real (fórmulas de la guía): Pcom = p1·Rc^1,3·(1 − 15 %), Pexp = 4·Pcom.
%   Trabajo = área encerrada (fórmula del polígono); 1 kg/cm²·cm³ = 0,0981 J.
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('Vu', 499.6, 'Rc', 10, 'p1', 1.033, 'gamma', 1.4, 'n_pol', 1.3, 'alfa', 4, 'perdida', 15));
c = sfm_colores();
V2 = p.Vu/(p.Rc - 1); V1 = p.Vu + V2;
% ciclo teórico
Vc = V1*(V2/V1).^linspace(0, 1, 60);  pc = p.p1*(V1./Vc).^p.gamma;
p2 = pc(end); p3 = p.alfa*p2;
Ve = V2*(V1/V2).^linspace(0, 1, 60);  pe = p3*(V2./Ve).^p.gamma;
Vt = [Vc Ve V1]; pt = [pc pe p.p1];
% ciclo real aproximado
Pcom = p.p1*p.Rc^p.n_pol*(1 - p.perdida/100); Pexp = Pcom*p.alfa;
k = linspace(0, 1, 40);
Vr1 = V1*(V2/V1).^k; pr1 = p.p1*(V1./Vr1).^p.n_pol.*(1 - p.perdida/100*k);
Vr2 = V2*[1.02 1.06 1.12]; pr2 = [Pcom*1.8 Pcom*3.2 Pexp];
Vr3 = 1.12*V2*(0.85*V1/(1.12*V2)).^linspace(0, 1, 40); pr3 = Pexp*(1.12*V2./Vr3).^p.n_pol;
Vr4 = [0.93*V1 V1 V2 V2 V1 V1]; pr4 = [(pr3(end) + 1.15*p.p1)/2*0.8, 1.15*p.p1, 1.1*p.p1, 0.9*p.p1, 0.9*p.p1, p.p1];
Vr = [Vr1 Vr2 Vr3 Vr4]; prr = [pr1 pr2 pr3 pr4];
area = @(x, y) 0.5*abs(sum(x(1:end-1).*y(2:end) - x(2:end).*y(1:end-1)));
Wt = area(Vt, pt); Wr = area(Vr, prr);
eta = 1 - 1/p.Rc^(p.gamma - 1);
R = struct('V1', V1, 'V2', V2, 'p2', p2, 'p3', p3, 'eta', eta, 'Pcom', Pcom, 'Pexp', Pexp, ...
    'W_teorico_J', 0.0981*Wt, 'W_real_J', 0.0981*Wr, 'pmi_teorica', Wt/p.Vu, 'pmi_real', Wr/p.Vu);

sfm_tabla('Ciclo Otto', { ...
    'Volumen de la cámara V2 (cm³)', V2, '%.2f', 'Vc = Vu/(Rc − 1)'; ...
    'Volumen total V1 (cm³)', V1, '%.2f', ''; ...
    'Presión final de compresión teórica p2 (kg/cm²)', p2, '%.2f', 'p1·Rc^γ'; ...
    'Presión máxima teórica p3 (kg/cm²)', p3, '%.2f', 'α·p2'; ...
    'Rendimiento térmico teórico (%)', eta*100, '%.1f', '1 − 1/Rc^(γ−1)'; ...
    'Presión de compresión real Pcom (kg/cm²)', Pcom, '%.2f', 'fórmula de la guía'; ...
    'Presión de explosión real Pexp (kg/cm²)', Pexp, '%.2f', '4·Pcom'; ...
    'Trabajo del ciclo teórico (J)', R.W_teorico_J, '%.1f', 'área encerrada'; ...
    'Trabajo neto del ciclo real (J)', R.W_real_J, '%.1f', 'incluye el lazo de bombeo'; ...
    'pmi teórica | real (kg/cm²)', sprintf('%.2f | %.2f', R.pmi_teorica, R.pmi_real), '', 'pmi = W/Vu'; ...
    'Factor de diagrama real/teórico (%)', Wr/Wt*100, '%.1f', ''});

sfm_fig('Ciclo Otto', 1100, 480);
subplot(1,2,1)
plot(Vt, pt, 'Color', c.azul, 'LineWidth', 1.8); hold on; plot(Vr, prr, 'Color', c.naranja, 'LineWidth', 1.8)
grid on; xlabel('V (cm³)'); ylabel('p (kg/cm²)'); title('Diagrama p–V'); legend('Teórico (Otto)', 'Real aproximado')
subplot(1,2,2)
rcs = 6:0.5:14; plot(rcs, (1 - 1./rcs.^(p.gamma - 1))*100, 'Color', c.verde, 'LineWidth', 1.8); hold on
plot(p.Rc, eta*100, 'ko', 'MarkerFaceColor', 'y'); grid on
xlabel('Relación de compresión Rc'); ylabel('\eta teórico (%)'); title('Rendimiento teórico según Rc')
sfm_titulo(sprintf('Ciclo Otto · Rc = %g · p1 = %g kg/cm²', p.Rc, p.p1));
end
