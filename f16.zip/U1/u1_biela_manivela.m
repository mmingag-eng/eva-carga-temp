function R = u1_biela_manivela(p)
%U1_BIELA_MANIVELA Cinemática del mecanismo biela-manivela.
%   R = u1_biela_manivela()            usa los valores de ejemplo.
%   R = u1_biela_manivela(p)           con p.S, p.L, p.n, p.m_alt.
%
%   Parámetros (estructura p):
%     S      carrera (mm)                                   [70]
%     L      longitud de la biela entre centros (mm)        [130]
%     n      régimen (rpm)                                  [4000]
%     m_alt  masa alternativa: pistón + bulón + segmentos
%            + 1/3 de la biela (kg)                         [0.55]
%
%   Modelo: x = r(1 − cos θ) + L(1 − √(1 − λ²·sen²θ)),
%           v = dx/dt (exacta), a ≈ r·ω²·(cos θ + λ·cos 2θ).
%   Unidad 1 · Sistemas del Funcionamiento del Motor (MA.02.06), ISTS.
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('S', 70, 'L', 130, 'n', 4000, 'm_alt', 0.55));
c = sfm_colores();

r = p.S/2;                      % radio de la manivela (mm)
lam = r/p.L;                    % relación biela-manivela
w = 2*pi*p.n/60;                % velocidad angular (rad/s)
th = linspace(0, 360, 721);
t = deg2rad(th);
raiz = sqrt(1 - lam^2*sin(t).^2);
x = r*(1 - cos(t)) + p.L*(1 - raiz);                       % mm
v = r/1000*w*(sin(t) + lam*sin(2*t)./(2*raiz));            % m/s
a = r/1000*w^2*(cos(t) + lam*cos(2*t));                    % m/s²
Fi = -p.m_alt*a;                                           % N (fuerza de inercia)

vm = 2*p.S*p.n/60/1000;
[vmax, k] = max(v);
R = struct('r', r, 'lambda', lam, 'omega', w, 'v_media', vm, 'v_max', vmax, ...
           'theta_vmax', th(k), 'a_PMS', r/1000*w^2*(1+lam), 'a_PMI', r/1000*w^2*(1-lam), ...
           'F_inercia_PMS', p.m_alt*r/1000*w^2*(1+lam), 'theta', th, 'x', x, 'v', v, 'a', a);

sfm_tabla('Cinemática biela-manivela', { ...
    'Radio de la manivela r (mm)', r, '%.1f', 'r = S/2'; ...
    'Relación biela-manivela λ = r/L', lam, '%.3f', 'típico 0,25–0,35'; ...
    'Velocidad angular ω (rad/s)', w, '%.1f', 'ω = 2πn/60'; ...
    'Velocidad media del pistón (m/s)', vm, '%.2f', 'vm = 2·S·n/60'; ...
    'Velocidad máxima del pistón (m/s)', vmax, '%.2f', ''; ...
    'Ángulo de la velocidad máxima (° tras el PMS)', th(k), '%.1f', 'antes de 90° por la oblicuidad de la biela'; ...
    'Aceleración en el PMS (m/s²)', R.a_PMS, '%.0f', 'r·ω²·(1+λ)'; ...
    'Aceleración en el PMI (m/s²)', R.a_PMI, '%.0f', 'r·ω²·(1−λ)'; ...
    'Aceleración en el PMS (número de g)', R.a_PMS/9.81, '%.0f', ''; ...
    'Fuerza de inercia en el PMS (N)', R.F_inercia_PMS, '%.0f', 'F = m·a'});

sfm_fig('Biela-manivela');
subplot(2,2,1); plot(th, x, 'Color', c.azul, 'LineWidth', 1.6); grid on
xlim([0 360]); set(gca, 'XTick', 0:45:360); xlabel('\theta (°)'); ylabel('x (mm)'); title('Desplazamiento desde el PMS')
subplot(2,2,2); plot(th, v, 'Color', c.naranja, 'LineWidth', 1.6); hold on
plot([0 360], [vm vm], '--', 'Color', c.gris); plot(th(k), vmax, 'o', 'Color', c.naranja, 'MarkerFaceColor', c.naranja)
grid on; xlim([0 360]); set(gca, 'XTick', 0:45:360); xlabel('\theta (°)'); ylabel('v (m/s)'); title('Velocidad del pistón')
legend('instantánea', 'media', 'máxima', 'Location', 'southwest')
subplot(2,2,3); plot(th, a, 'Color', c.morado, 'LineWidth', 1.6); grid on
xlim([0 360]); set(gca, 'XTick', 0:45:360); xlabel('\theta (°)'); ylabel('a (m/s²)'); title('Aceleración del pistón')
subplot(2,2,4); plot(th, Fi, 'Color', c.rojo, 'LineWidth', 1.6); grid on
xlim([0 360]); set(gca, 'XTick', 0:45:360); xlabel('\theta (°)'); ylabel('F (N)'); title('Fuerza de inercia de las masas alternativas')
sfm_titulo(sprintf('Biela-manivela · S = %g mm, L = %g mm, n = %g rpm', p.S, p.L, p.n));
end
