function R = u1_alexometro(p)
%U1_ALEXOMETRO Medición de un cilindro con alexómetro (comparador de interiores).
%   R = u1_alexometro(p) simula la lectura de la esfera respecto de la
%   medida de referencia y, opcionalmente, las seis lecturas del cilindro.
%
%   Parámetros (estructura p):
%     D_ref             medida de referencia ajustada con el micrómetro (mm) [86.00]
%     desviacion        diferencia real (mm); [] = aleatoria (−0,10…+0,20)   []
%     ejercicio         semilla                                              [1]
%     respuesta         su diámetro (mm)                                     []
%     mostrar_solucion  true/false                                           [true]
%
%   Convención: con el diámetro MAYOR que la referencia el palpador se
%   extiende y la aguja gira en sentido ANTIHORARIO (lado «+» de la esfera).
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('D_ref', 86.00, 'desviacion', [], 'ejercicio', 1, 'respuesta', [], 'mostrar_solucion', true));
c = sfm_colores();
if isempty(p.desviacion)
    rng(4000 + p.ejercicio);
    dev = 0.01*round(-10 + rand*30);
else
    dev = 0.01*round(p.desviacion/0.01);
end
D = p.D_ref + dev;
R = struct('D', D, 'desviacion', dev, 'divisiones', round(dev/0.01));

sfm_fig('Alexómetro', 650, 700); hold on; axis equal; axis off
t = linspace(0, 2*pi, 200);
fill(cos(t), sin(t), [0.98 0.98 0.96], 'EdgeColor', [0.3 0.3 0.3], 'LineWidth', 1.5);
for k = -50:49
    a = pi/2 - 2*pi*k/100; l = 0.06; if mod(k, 5) == 0, l = 0.1; end
    if mod(k, 10) == 0, l = 0.14;
        text(0.76*cos(a), 0.76*sin(a), sprintf('%d', abs(k)), 'HorizontalAlignment', 'center', 'FontSize', 9);
    end
    plot([1 - l, 1]*cos(a), [1 - l, 1]*sin(a), 'k');
end
text(-0.35, 0.35, '+', 'FontSize', 22, 'Color', c.verde, 'HorizontalAlignment', 'center');
text(0.35, 0.35, '−', 'FontSize', 22, 'Color', c.rojo, 'HorizontalAlignment', 'center');
a = pi/2 + 2*pi*dev/1.0;               % antihorario si dev > 0 (1 mm por vuelta)
col = 'k'; if p.mostrar_solucion, col = c.rojo; end
plot([0 0.9*cos(a)], [0 0.9*sin(a)], 'Color', col, 'LineWidth', 2.2); plot(0, 0, 'ko', 'MarkerFaceColor', 'k');
title(sprintf('Alexómetro · referencia %.2f mm · ejercicio %d', p.D_ref, p.ejercicio));
text(0, -1.12, 'Puesto a cero sobre el micrómetro · apreciación 0,01 mm', 'HorizontalAlignment', 'center', 'FontSize', 9);
if dev >= 0, sg = '+'; else, sg = '-'; end
sol = sprintf('Aguja en %d divisiones del lado «%s»  ->  D = %.2f %s %.2f = %.2f mm', abs(R.divisiones), sg, p.D_ref, sg, abs(dev), D);
if ~isempty(p.respuesta)
    ok = abs(p.respuesta - D) < 0.005; R.correcta = ok;
    if ok, fprintf('\nSu respuesta %.2f es CORRECTA.\n', p.respuesta); else, fprintf('\nSu respuesta %.2f es incorrecta.\n', p.respuesta); end
end
if p.mostrar_solucion
    fprintf('\nSOLUCIÓN: %s\n', sol); text(0, -1.3, sol, 'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'Color', c.rojo);
end
axis([-1.3 1.3 -1.4 1.2]);
end
