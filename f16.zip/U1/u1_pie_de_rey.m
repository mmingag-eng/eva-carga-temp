function R = u1_pie_de_rey(p)
%U1_PIE_DE_REY Simulador de lectura del calibrador pie de rey (mm y pulgadas).
%   R = u1_pie_de_rey(p) dibuja la regla y el nonio en la posición de una
%   lectura (dada o aleatoria) y muestra la solución comentada.
%
%   Parámetros (estructura p):
%     sistema           'mm' o 'pulg'                                  ['mm']
%     resolucion        mm: 0.1 · 0.05 · 0.02 | pulg: 0.001 · 1/128     [0.05]
%     lectura           valor a representar; [] = aleatoria             []
%     ejercicio         número de ejercicio (semilla del azar)          [1]
%     respuesta         su lectura, para autocorregir; [] = no corrige   []
%     mostrar_solucion  true/false                                      [true]
%
%   Ejemplos:
%     u1_pie_de_rey(struct('sistema','pulg','resolucion',1/128,'ejercicio',4))
%     u1_pie_de_rey(struct('ejercicio',7,'respuesta',23.45,'mostrar_solucion',false))
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('sistema', 'mm', 'resolucion', 0.05, 'lectura', [], 'ejercicio', 1, ...
    'respuesta', [], 'mostrar_solucion', true));
c = sfm_colores();
res = p.resolucion;
if strcmpi(p.sistema, 'mm')
    m = 1; k = 1 + (abs(res - 0.05) < 1e-9); u = 'mm'; rango = [5 140];
    if all(abs(res - [0.1 0.05 0.02]) > 1e-9), error('Resolución en mm: 0.1, 0.05 o 0.02'); end
else
    u = 'pulg'; k = 1; rango = [0.2 5];
    if abs(res - 0.001) < 1e-9, m = 0.025; elseif abs(res - 1/128) < 1e-9, m = 1/16;
    else, error('Resolución en pulgadas: 0.001 o 1/128'); end
end
N = round(m/res);                 % divisiones del nonio
d = k*m - res;                    % paso del nonio
if isempty(p.lectura)
    rng(1000 + p.ejercicio);
    L = res*round((rango(1) + rand*(diff(rango)))/res);
else
    L = res*round(p.lectura/res);
end
j = mod(round(L/res), N);         % línea del nonio que coincide
principal = L - j*res;            % lectura de la regla (antes del cero del nonio)

% ---------------------------------------------------------------- dibujo
sfm_fig('Pie de rey', 1150, 420); hold on; axis off
x0 = L - 3*m; x1 = L + N*d + 3*m;
if strcmpi(u, 'pulg') && N == 8, x0 = floor(L) - m; x1 = max(x1, floor(L) + 1 + m); end
i0 = ceil(x0/m); i1 = floor(x1/m);
for i = i0:i1
    xx = i*m; h = 0.5;
    if strcmpi(u, 'mm')
        if mod(i, 10) == 0, h = 1; text(xx, 1.15, sprintf('%d', i/10), 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
        elseif mod(i, 5) == 0, h = 0.75; end
    elseif m == 0.025
        if mod(i, 40) == 0, h = 1.1; text(xx, 1.25, sprintf('%d', i/40), 'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'FontSize', 12);
        elseif mod(i, 4) == 0, h = 1; text(xx, 1.12, sprintf('%d', mod(i/4, 10)), 'HorizontalAlignment', 'center');
        elseif mod(i, 2) == 0, h = 0.75; end
    else
        if mod(i, 16) == 0, h = 1.1; text(xx, 1.25, sprintf('%d"', i/16), 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
        elseif mod(i, 8) == 0, h = 0.9; elseif mod(i, 4) == 0, h = 0.75; elseif mod(i, 2) == 0, h = 0.6; end
    end
    plot([xx xx], [0 h], 'k', 'LineWidth', 1);
end
plot([x0 x1], [0 0], 'k', 'LineWidth', 1.2);
fill([L-0.6*m L+N*d+0.6*m L+N*d+0.6*m L-0.6*m], [0 0 -1.6 -1.6], [0.93 0.95 0.98], 'EdgeColor', [0.6 0.6 0.6]);
paso_lab = max(1, round(N/10)); if N == 25, paso_lab = 5; end
for jj = 0:N
    xx = L + jj*d; h = 0.6; col = 'k'; lw = 1;
    if mod(jj, paso_lab) == 0
        h = 0.9;
        if strcmpi(u, 'mm'), lab = sprintf('%g', jj*res*10);
        else, lab = sprintf('%d', jj); end
        text(xx, -1.15, lab, 'HorizontalAlignment', 'center', 'FontSize', 9);
    end
    if jj == j && p.mostrar_solucion, col = c.rojo; lw = 2.5; end
    plot([xx xx], [0 -h], 'Color', col, 'LineWidth', lw);
end
text(L, -1.45, 'cero del nonio', 'HorizontalAlignment', 'center', 'FontSize', 8, 'Color', c.azul);
axis([x0 x1 -2 1.6]);
if strcmpi(u, 'mm'), tit = sprintf('Pie de rey en mm · apreciación %g mm · ejercicio %d', res, p.ejercicio);
elseif N == 8, tit = sprintf('Pie de rey en pulgadas · apreciación 1/128" · ejercicio %d', p.ejercicio);
else, tit = sprintf('Pie de rey en pulgadas · apreciación 0,001" · ejercicio %d', p.ejercicio); end
title(tit, 'FontSize', 12);

% ---------------------------------------------------------------- solución
R = struct('lectura', L, 'regla', principal, 'division_nonio', j, 'unidad', u);
if strcmpi(u, 'pulg') && abs(res - 1/128) < 1e-9
    sol = sprintf('Regla: %s  +  nonio: línea %d × 1/128"  =  %s', local_frac(principal), j, local_frac(L));
else
    sol = sprintf('Regla: %.3f %s  +  nonio: línea %d × %g = %.3f  ->  lectura = %.3f %s', principal, u, j, res, j*res, L, u);
end
if ~isempty(p.respuesta)
    ok = abs(p.respuesta - L) < res/2;
    if ok, msg = sprintf('Su respuesta %.4g es CORRECTA.', p.respuesta);
    else, msg = sprintf('Su respuesta %.4g es incorrecta.', p.respuesta); end
    fprintf('\n%s\n', msg); R.correcta = ok;
    text(x0, 1.5, msg, 'FontWeight', 'bold', 'Color', c.verde*ok + c.rojo*(~ok));
end
if p.mostrar_solucion
    fprintf('\nSOLUCIÓN: %s\n', sol);
    text((x0 + x1)/2, -1.85, sol, 'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'Color', c.rojo);
else
    fprintf('\nEscriba su lectura en p.respuesta y vuelva a ejecutar para comprobarla.\n');
end
end

function s = local_frac(x)
n = round(x*128); e = floor(n/128); r = mod(n, 128); den = 128;
while r > 0 && mod(r, 2) == 0, r = r/2; den = den/2; end
if r == 0, s = sprintf('%d"', e);
elseif e == 0, s = sprintf('%d/%d"', r, den);
else, s = sprintf('%d %d/%d"', e, r, den); end
end
