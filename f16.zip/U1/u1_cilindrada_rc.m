function R = u1_cilindrada_rc(p)
%U1_CILINDRADA_RC Cilindrada, relación de compresión y efecto del cepillado y la sobremedida.
%   R = u1_cilindrada_rc(p)
%
%   Parámetros (estructura p):
%     D          diámetro del cilindro (mm)                          [76]
%     S          carrera (mm)                                        [70]
%     z          número de cilindros                                 [4]
%     V_culata   volumen de la cámara en la culata (cm³)             [28]
%     e_junta    espesor comprimido de la junta (mm)                 [1.2]
%     D_junta    diámetro interior de la junta (mm)                  [78]
%     V_piston   volumen del rebaje (+) o cúpula (−) del pistón (cm³)[3]
%     h_piston   distancia del pistón al plano en el PMS (mm)        [0.3]
%     cepillado  material retirado de la culata (mm)                 [0]
%     sobremedida rectificado del cilindro (mm)                      [0]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('D', 76, 'S', 70, 'z', 4, 'V_culata', 28, 'e_junta', 1.2, 'D_junta', 78, ...
    'V_piston', 3, 'h_piston', 0.3, 'cepillado', 0, 'sobremedida', 0));
c = sfm_colores();

calc = @(D, cep) local_calc(p, D, cep);
O = calc(p.D, 0);
Mo = calc(p.D + p.sobremedida, p.cepillado);
R = struct('original', O, 'modificado', Mo);

sfm_tabla('Cilindrada y relación de compresión (original | modificado)', { ...
    'Área del pistón (cm²)', sprintf('%.2f | %.2f', O.A, Mo.A), '', 'A = π·D²/4'; ...
    'Cilindrada unitaria Vu (cm³)', sprintf('%.1f | %.1f', O.Vu, Mo.Vu), '', 'Vu = A·S'; ...
    'Volumen de la junta (cm³)', sprintf('%.2f | %.2f', O.Vj, Mo.Vj), '', ''; ...
    'Volumen sobre el pistón en el PMS (cm³)', sprintf('%.2f | %.2f', O.Vp, Mo.Vp), '', ''; ...
    'Volumen en la culata (cm³)', sprintf('%.2f | %.2f', O.Vcul, Mo.Vcul), '', 'el cepillado resta A·x'; ...
    'Volumen total de la cámara Vcc (cm³)', sprintf('%.2f | %.2f', O.Vcc, Mo.Vcc), '', ''; ...
    'Relación de compresión Rc', sprintf('%.2f | %.2f', O.Rc, Mo.Rc), '', 'Rc = (Vu + Vcc)/Vcc'; ...
    'Cilindrada total VT (cm³)', sprintf('%.0f | %.0f', O.VT, Mo.VT), '', 'VT = Vu·z'});
if Mo.Rc > 11
    fprintf('  ATENCIÓN: Rc modificada > 11, riesgo de detonación con gasolina de bajo octanaje.\n');
end

x = 0:0.05:1;
rc = zeros(size(x));
for k = 1:numel(x)
    tmp = calc(p.D + p.sobremedida, x(k)); rc(k) = tmp.Rc;
end
sfm_fig('Cilindrada y Rc', 900, 500);
plot(x, rc, '-o', 'Color', c.rojo, 'MarkerFaceColor', c.rojo, 'MarkerSize', 4, 'LineWidth', 1.5); hold on
plot(p.cepillado, Mo.Rc, 'ks', 'MarkerFaceColor', 'y', 'MarkerSize', 9)
grid on; xlabel('Material retirado de la culata (mm)'); ylabel('Rc')
title('Relación de compresión según el cepillado (con la sobremedida indicada)')
sfm_linea('y', 11, 'k--', 'Rc = 11');
legend('Rc', 'Situación actual', 'Location', 'northwest')
end

function o = local_calc(p, D, cep)
o.A = pi/4*(D/10)^2;
o.Vu = o.A*p.S/10;
o.Vj = pi/4*(p.D_junta/10)^2*p.e_junta/10;
o.Vp = o.A*p.h_piston/10;
o.Vcul = p.V_culata - o.A*cep/10;
o.Vcc = o.Vcul + o.Vj + p.V_piston + o.Vp;
o.Rc = (o.Vu + o.Vcc)/o.Vcc;
o.VT = o.Vu*p.z;
end
