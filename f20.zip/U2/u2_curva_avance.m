function R = u2_curva_avance(p)
%U2_CURVA_AVANCE Curva de avance al encendido: inicial + centrífugo + vacío.
%   R = u2_curva_avance(p)
%
%   Parámetros (estructura p):
%     inicial        avance inicial o estático (°)                 [8]
%     c_n0, c_n1     centrífugo: rpm de inicio y de máximo          [1000 4000]
%     c_max          centrífugo: avance máximo (°)                  [24]
%     v_p0, v_p1     vacío: depresión de inicio y de máximo (mbar)  [100 350]
%     v_max          vacío: avance máximo (°)                       [15]
%     depresion      depresión a carga parcial estudiada (mbar)     [300]
%     n              régimen de estudio (rpm)                       [3000]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('inicial', 8, 'c_n0', 1000, 'c_n1', 4000, 'c_max', 24, 'v_p0', 100, 'v_p1', 350, ...
    'v_max', 15, 'depresion', 300, 'n', 3000));
c = sfm_colores();
cen = @(n) p.c_max*min(1, max(0, (n - p.c_n0)/(p.c_n1 - p.c_n0)));
vac = @(dp) p.v_max*min(1, max(0, (dp - p.v_p0)/(p.v_p1 - p.v_p0)));
a_pl = p.inicial + cen(p.n); a_pa = a_pl + vac(p.depresion);
R = struct('centrifugo', cen(p.n), 'vacio', vac(p.depresion), 'plena_carga', a_pl, 'carga_parcial', a_pa, ...
    't_ms', a_pa/(6*p.n)*1000);
sfm_tabla('Curva de avance', { ...
    'Avance centrífugo (°)', R.centrifugo, '%.1f', 'lineal entre c_n0 y c_n1'; ...
    'Avance por vacío (°)', R.vacio, '%.1f', 'lineal entre v_p0 y v_p1'; ...
    'Avance total a plena carga (°)', a_pl, '%.1f', 'inicial + centrífugo'; ...
    'Avance total a carga parcial (°)', a_pa, '%.1f', '+ vacío'; ...
    'Adelanto de la chispa (ms)', R.t_ms, '%.2f', 't = θ/(6·n)'});
nn = 500:50:6500;
sfm_fig('Curva de avance', 900, 480);
plot(nn, p.inicial + arrayfun(cen, nn), 'Color', c.azul, 'LineWidth', 1.8); hold on
plot(nn, p.inicial + arrayfun(cen, nn) + vac(p.depresion), 'Color', c.naranja, 'LineWidth', 1.8)
plot(p.n, a_pl, 'o', 'Color', c.azul, 'MarkerFaceColor', c.azul); plot(p.n, a_pa, 'o', 'Color', c.naranja, 'MarkerFaceColor', c.naranja)
grid on; xlabel('Régimen (rpm)'); ylabel('Avance (° antes del PMS)')
legend('Plena carga (inicial + centrífugo)', sprintf('Carga parcial (+ vacío a %g mbar)', p.depresion), 'Location', 'southeast')
title('Avance al encendido según el régimen y la carga')
end
