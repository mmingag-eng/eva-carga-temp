function R = u2_lambda_gases(p)
%U2_LAMBDA_GASES Relación aire-combustible, factor λ y gases de escape (modelo cualitativo).
%   R = u2_lambda_gases(p)
%
%   Parámetros (estructura p):
%     m_aire    masa de aire aspirada (kg/h)         [120]
%     m_comb    masa de combustible (kg/h)           [8.6]
%     esteq     relación estequiométrica             [14.7]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('m_aire', 120, 'm_comb', 8.6, 'esteq', 14.7));
c = sfm_colores();
afr = p.m_aire/p.m_comb; L = afr/p.esteq;
G = local_gases(L);
if L < 0.97, est = 'Mezcla rica: falta aire'; elseif L > 1.03, est = 'Mezcla pobre: sobra aire'; else, est = 'Ventana lambda (estequiométrica)'; end
R = struct('AFR', afr, 'lambda', L, 'gases', G, 'estado', est);
sfm_tabla('Lambda y gases de escape', { ...
    'Relación aire-combustible real', afr, '%.1f', ''; 'Factor λ', L, '%.3f', est; ...
    'CO (%)', G.CO, '%.2f', ''; 'CO₂ (%)', G.CO2, '%.1f', ''; 'O₂ (%)', G.O2, '%.2f', ''; ...
    'HC (ppm)', G.HC, '%.0f', ''; 'NOx (ppm)', G.NOx, '%.0f', ''});
l = linspace(0.8, 1.3, 201); g = local_gases(l);
sfm_fig('Lambda y gases', 1100, 450);
subplot(1,2,1); plot(l, g.CO, 'Color', c.rojo, 'LineWidth', 1.8); hold on
plot(l, g.CO2, 'Color', c.gris, 'LineWidth', 1.8); plot(l, g.O2, 'Color', c.azul, 'LineWidth', 1.8)
plot([L L], [0 16], 'k--'); grid on; xlabel('\lambda'); ylabel('% en volumen'); legend('CO', 'CO_2', 'O_2', 'λ actual'); title('Gases en porcentaje')
subplot(1,2,2); plot(l, g.HC, 'Color', c.dorado, 'LineWidth', 1.8); hold on; plot(l, g.NOx, 'Color', c.morado, 'LineWidth', 1.8)
plot([L L], [0 3000], 'k--'); ylim([0 3000]); grid on; xlabel('\lambda'); ylabel('ppm'); legend('HC', 'NO_x', 'λ actual'); title('Gases en ppm')
sfm_titulo(sprintf('λ = %.3f · %s (modelo didáctico)', L, est));
end

function G = local_gases(L)
G.CO = (L < 1).*(0.3 + 33*(1 - L)) + (L >= 1).*(0.3*exp(-15*(L - 1)));
G.CO2 = (L < 1).*(14.7 - 22*(1 - L)) + (L >= 1).*(14.7./L);
G.O2 = (L > 1).*(0.3 + 20.9*(L - 1)./L) + (L <= 1).*(0.3*exp(-10*(1 - L)));
G.HC = (L < 1.05).*(120 + 18000*(L - 1.05).^2) + (L >= 1.05).*(120 + (L > 1.15).*40000.*(L - 1.15).^2);
G.NOx = 2800*exp(-((L - 1.08)/0.12).^2);
end
