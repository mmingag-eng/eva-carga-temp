function R = u2_dwell_bobina(p)
%U2_DWELL_BOBINA Ángulo de cierre (dwell) y saturación de la bobina de encendido.
%   R = u2_dwell_bobina(p)
%
%   Parámetros (estructura p):
%     z      número de cilindros                       [4]
%     dwell  ángulo de cierre (° de distribuidor)      [54]
%     V      tensión de alimentación (V)               [13.5]
%     Rp     resistencia del primario (Ω)              [3.0]
%     Lp     inductancia del primario (mH)             [7]
%     n      régimen de estudio (rpm del motor)        [3000]
%
%   I(t) = V/R·(1 − e^(−t/τ)), τ = L/R; t_cierre = dwell/360 · 60/(n/2).
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('z', 4, 'dwell', 54, 'V', 13.5, 'Rp', 3.0, 'Lp', 7, 'n', 3000));
c = sfm_colores();
ang = 360/p.z; tau = p.Lp/p.Rp;                 % ms
Imax = p.V/p.Rp;
tc = @(n) p.dwell*120000./(360*n);             % ms
I = @(t) Imax*(1 - exp(-t/tau));
t0 = tc(p.n); I0 = I(t0); E = 0.5*p.Lp*I0^2;  % mJ (L en mH)
R = struct('dwell_pct', p.dwell/ang*100, 'tau_ms', tau, 't_cierre_ms', t0, 'I_corte', I0, 'E_mJ', E, 'saturacion', I0/Imax);
sfm_tabla('Dwell y saturación de la bobina', { ...
    'Ángulo entre chispas (° distribuidor)', ang, '%.1f', '360/z'; ...
    'Dwell (%)', R.dwell_pct, '%.1f', ''; ...
    'Dwell en grados de cigüeñal', 2*p.dwell, '%.0f', ''; ...
    'Constante de tiempo τ (ms)', tau, '%.2f', 'L/R'; ...
    'Corriente máxima posible (A)', Imax, '%.2f', 'V/R'; ...
    'Tiempo de cierre (ms)', t0, '%.2f', 'dwell/360·60/(n/2)'; ...
    'Corriente al corte (A)', I0, '%.2f', 'V/R·(1−e^(−t/τ))'; ...
    'Energía almacenada (mJ)', E, '%.1f', '½·L·I²'; ...
    'Saturación (%)', R.saturacion*100, '%.1f', ''});
if R.saturacion < 0.8, fprintf('  A este régimen la bobina no se carga del todo: la chispa se debilita.\n'); end

sfm_fig('Dwell y bobina', 1100, 450);
subplot(1,2,1); t = linspace(0, max(6*tau, 1.1*tc(1000)), 300); plot(t, I(t), 'Color', c.azul, 'LineWidth', 1.8); hold on
rr = [1000 3000 6000];
for k = 1:3, plot(tc(rr(k)), I(tc(rr(k))), 'o', 'MarkerSize', 8, 'LineWidth', 1.5); end
grid on; xlabel('t (ms)'); ylabel('I primario (A)'); title('Carga de la bobina')
legend('I(t)', '1000 rpm', '3000 rpm', '6000 rpm', 'Location', 'southeast')
subplot(1,2,2); nn = 500:100:7000; plot(nn, 0.5*p.Lp*I(tc(nn)).^2, 'Color', c.naranja, 'LineWidth', 1.8); grid on
xlabel('Régimen (rpm)'); ylabel('Energía (mJ)'); title('Energía disponible para la chispa')
sfm_titulo(sprintf('Encendido convencional · %d cilindros · dwell %g°', p.z, p.dwell));
end
