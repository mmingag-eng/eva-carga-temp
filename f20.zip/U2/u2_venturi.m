function R = u2_venturi(p)
%U2_VENTURI Venturi del carburador elemental: depresión (Bernoulli) y dosificación.
%   R = u2_venturi(p)
%
%   Parámetros (estructura p):
%     VT       cilindrada total (cm³)                    [1600]
%     n        régimen (rpm)                             [3000]
%     etav     rendimiento volumétrico                   [0.80]
%     apertura apertura de la mariposa (%)               [100]
%     d1, d2   diámetro del colector y del difusor (mm)  [32 24]
%     rho_a    densidad del aire (kg/m³) (Loja ≈ 0,95)    [0.95]
%     d_j      diámetro del chiclé principal (mm)        [1.55]
%     Cd       coeficiente de descarga del chiclé        [0.70]
%     rho_c    densidad de la gasolina (kg/m³)           [740]
%     h        desnivel surtidor–cuba (mm)               [5]
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('VT', 1600, 'n', 3000, 'etav', 0.80, 'apertura', 100, 'd1', 32, 'd2', 24, ...
    'rho_a', 0.95, 'd_j', 1.55, 'Cd', 0.70, 'rho_c', 740, 'h', 5));
c = sfm_colores();
S = local_calc(p, p.n);
R = S;
sfm_tabla('Venturi del carburador', { ...
    'Caudal de aire (m³/s)', S.Q, '%.4f', 'VT·(n/2)/60·ηv·apertura'; ...
    'Velocidad en el colector v1 (m/s)', S.v1, '%.1f', ''; 'Velocidad en el difusor v2 (m/s)', S.v2, '%.1f', ''; ...
    'Depresión en el difusor (Pa)', S.dp, '%.0f', 'Bernoulli: ρ/2·(v2² − v1²)'; ...
    'Depresión (mmH₂O)', S.dp/9.81, '%.0f', ''; 'Depresión mínima para elevar la gasolina (Pa)', S.dp_min, '%.1f', 'ρc·g·h'; ...
    'Masa de aire (g/s)', S.ma*1000, '%.2f', ''; 'Masa de gasolina (g/s)', S.mc*1000, '%.3f', 'Cd·A·√(2ρc(Δp − ρc g h))'; ...
    'Relación A/C', S.AC, '%.1f', ''; 'λ', S.lambda, '%.2f', ''; 'Consumo (L/h)', S.mc*3600/p.rho_c*1000, '%.1f', ''});
nn = 600:100:6000; dp = zeros(size(nn)); la = nan(size(nn));
for k = 1:numel(nn), t = local_calc(p, nn(k)); dp(k) = t.dp/9.81; la(k) = t.lambda; end
sfm_fig('Venturi', 1100, 450);
subplot(1,2,1); plot(nn, dp, 'Color', c.azul, 'LineWidth', 1.8); grid on; xlabel('Régimen (rpm)'); ylabel('\Deltap (mmH_2O)'); title('Depresión en el difusor')
subplot(1,2,2); plot(nn, la, 'Color', c.naranja, 'LineWidth', 1.8); hold on; plot(nn([1 end]), [1 1], 'k--'); ylim([0.6 2]); grid on
xlabel('Régimen (rpm)'); ylabel('\lambda'); title('Riqueza del circuito principal'); legend('λ', 'λ = 1')
sfm_titulo('Carburador elemental (sin compensación): por qué hacen falta los circuitos auxiliares');
end

function S = local_calc(p, n)
S.Q = p.VT/1e6*n/2/60*p.etav*p.apertura/100;
S.v1 = S.Q/(pi/4*(p.d1/1000)^2); S.v2 = S.Q/(pi/4*(p.d2/1000)^2);
S.dp = p.rho_a/2*(S.v2^2 - S.v1^2);
S.dp_min = p.rho_c*9.81*p.h/1000;
S.ma = p.rho_a*S.Q;
if S.dp > S.dp_min
    S.mc = p.Cd*pi/4*(p.d_j/1000)^2*sqrt(2*p.rho_c*(S.dp - S.dp_min));
    S.AC = S.ma/S.mc; S.lambda = S.AC/14.7;
else
    S.mc = 0; S.AC = Inf; S.lambda = NaN;
end
end
