function R = u2_oscilograma(p)
%U2_OSCILOGRAMA Oscilograma del secundario de encendido y diagnóstico de fallas.
%   R = u2_oscilograma(p)
%
%   Parámetros (estructura p):
%     n          régimen (rpm), 600–3000                   [900]
%     z          número de cilindros                       [4]
%     dwell      ángulo de cierre (%)                      [55]
%     falla      1 Normal · 2 Luz de bujía excesiva · 3 Cable cortado ·
%                4 Mezcla pobre · 5 Bujía engrasada · 6 Bobina débil   [1]
%     examen     true: la falla se elige al azar y se oculta            [false]
%     ejercicio  semilla del modo examen                                [1]
%     respuesta  número de falla que diagnostica el estudiante          []
if nargin < 1, p = struct(); end
p = sfm_param(p, struct('n', 900, 'z', 4, 'dwell', 55, 'falla', 1, 'examen', false, 'ejercicio', 1, 'respuesta', []));
c = sfm_colores();
F = {'Normal', 10, 1.5, 1.5, 0.1, 3.0, 'Tensión de encendido 8–12 kV, chispa casi plana de 1–2 ms y 3–5 oscilaciones.';
     'Luz de bujía excesiva', 18, 2.2, 0.9, 0.3, 3.0, 'Encendido alto y chispa corta: luz excesiva o electrodos desgastados.';
     'Cable de bujía cortado', 28, 4.0, 0.3, 0.0, 2.0, 'Pico muy alto y casi sin chispa: cable de alta abierto. Riesgo para la bobina.';
     'Mezcla pobre', 14, 2.0, 1.0, 1.2, 3.0, 'Encendido elevado y chispa ascendente: mezcla pobre o entrada de aire.';
     'Bujía engrasada o en corto', 5, 0.8, 2.3, 0.0, 1.5, 'Encendido bajo y chispa larga: bujía engrasada, carbonizada o aislador fisurado.';
     'Bobina débil o con fuga', 7, 1.2, 0.8, 0.0, 1.0, 'Pocas oscilaciones y tensiones bajas: bobina débil o primario deficiente.'};
if p.examen, rng(5000 + p.ejercicio); k = randi(6); else, k = p.falla; end
kv = F{k,2}; ks = F{k,3}; ts = F{k,4}; pend = F{k,5}; osc = F{k,6};
T = 120000/(p.n*p.z); tcl = T*(1 - p.dwell/100);
t = unique([linspace(0, 0.07, 8), linspace(0.07, min(4, tcl), 300), linspace(min(4, tcl), tcl, 60), ...
            linspace(tcl, min(T, tcl + 1.5), 150), linspace(min(T, tcl + 1.5), T, 40)]);
v = zeros(size(t));
for i = 1:numel(t)
    b = t(i);
    if b <= 0.03, v(i) = kv*b/0.03;
    elseif b <= 0.07, v(i) = kv - (kv - ks)*(b - 0.03)/0.04;
    elseif b <= 0.07 + ts, v(i) = ks + pend*(b - 0.07);
    elseif b < tcl, v(i) = osc*exp(-(b - 0.07 - ts)/0.35)*sin(2*pi*4*(b - 0.07 - ts));
    else, v(i) = -2.5*exp(-(b - tcl)/0.25)*sin(2*pi*6*(b - tcl)); end
end
tt = [0 t + 1, T + 1.03, T + 1.07]; vv = [0 v kv ks];
R = struct('falla', k, 'T_ms', T, 't_cierre_ms', T*p.dwell/100, 'kV_encendido', kv, 'kV_chispa', ks, 'duracion_chispa_ms', ts);
if p.examen, nom = '(oculta)'; else, nom = F{k,1}; end
sfm_tabla('Oscilograma del secundario', { ...
    'Falla simulada', nom, '', ''; 'Ciclo de un cilindro (ms)', T, '%.1f', '120000/(n·z)'; ...
    'Tiempo de cierre del primario (ms)', T*p.dwell/100, '%.1f', ''; 'Tensión de encendido (kV)', kv, '%.1f', ''; ...
    'Tensión de la chispa (kV)', ks, '%.1f', ''; 'Duración de la chispa (ms)', ts, '%.1f', ''});
if ~p.examen, fprintf('  Diagnóstico: %s\n', F{k,7}); end
if ~isempty(p.respuesta)
    if p.respuesta == k, fprintf('\n¡Correcto! %s\n', F{k,7}); else, fprintf('\nIncorrecto: observe el pico, la línea de chispa y las oscilaciones.\n'); end
end
if p.examen && isempty(p.respuesta)
    fprintf('\nModo examen: indique p.respuesta = 1…6 (%s).\n', strjoin(F(:,1)', ' · '));
end
sfm_fig('Oscilograma', 1100, 520);
subplot(2,1,1); plot(tt, vv, 'Color', c.azul, 'LineWidth', 1.4); grid on; ylim([-5 30]); xlim([0 T + 2])
xlabel('t (ms)'); ylabel('kV'); title('Ciclo completo de un cilindro')
subplot(2,1,2); plot(tt, vv, 'Color', c.naranja, 'LineWidth', 1.6); grid on; ylim([-5 30]); xlim([0 6])
xlabel('t (ms)'); ylabel('kV'); title('Detalle: línea de encendido, chispa y oscilaciones')
sfm_titulo(sprintf('Oscilograma del secundario · %s · %d rpm', nom, p.n));
end
